import React, { useState, useEffect } from 'react';
import { SAMPLE_BOOKS } from './data/sampleBooks';
import { Book, CartItem, Order, ContactMessage } from './types';
import { StoreHeader } from './components/store/StoreHeader';
import { StoreFooter } from './components/store/StoreFooter';
import { HomePage } from './components/store/HomePage';
import { BooksPage } from './components/store/BooksPage';
import { BookDetailsModal } from './components/store/BookDetailsModal';
import { CartPage } from './components/store/CartPage';
import { CheckoutModal } from './components/store/CheckoutModal';
import { OrderSuccessModal } from './components/store/OrderSuccessModal';
import { AboutPage } from './components/store/AboutPage';
import { ContactPage } from './components/store/ContactPage';
import { DatabaseInspector } from './components/store/DatabaseInspector';

// Project Companion Views
import { SourceCodeViewer } from './components/companion/SourceCodeViewer';
import { VisualStudioGuide } from './components/companion/VisualStudioGuide';
import { GitHubGuide } from './components/companion/GitHubGuide';
import { ProjectReportViewer } from './components/companion/ProjectReportViewer';
import { VivaPreparation } from './components/companion/VivaPreparation';
import { TestingChecklistViewer } from './components/companion/TestingChecklistViewer';

export default function App() {
  // Navigation & View Mode
  const [appMode, setAppMode] = useState<
    'store' | 'code' | 'vs-guide' | 'github-guide' | 'report' | 'viva' | 'testing'
  >('store');
  const [storePage, setStorePage] = useState<'home' | 'books' | 'about' | 'contact' | 'cart'>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Database & State
  const [books] = useState<Book[]>(SAMPLE_BOOKS);

  // Cart State (stored in localStorage)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('booknest_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Orders State (seeded with an initial completed order)
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('booknest_orders');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        orderId: 1001,
        orderCode: 'BN-2026-1001',
        customerName: 'Aarav Patel',
        email: 'aarav.patel@bca-college.edu',
        phone: '9876543210',
        address: 'Room 302, Boys Hostel Block B, College Campus',
        orderDate: '21/09/2026, 11:30 AM',
        totalAmount: 1198,
        status: 'Delivered',
        items: [
          {
            orderDetailId: 1,
            orderId: 1001,
            bookId: 1,
            bookName: 'C# 10 and .NET 6 – Modern Cross-Platform Development',
            quantity: 1,
            price: 649,
          },
          {
            orderDetailId: 2,
            orderId: 1001,
            bookId: 4,
            bookName: 'Database System Concepts (Silberschatz)',
            quantity: 1,
            price: 549,
          },
        ],
      },
    ];
  });

  // Contact Messages State (seeded with initial inquiry)
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(() => {
    try {
      const saved = localStorage.getItem('booknest_contacts');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        contactId: 1,
        name: 'Sneha Rao',
        email: 'sneha.rao@college.edu',
        phone: '9845012345',
        message: 'Are multiple copies of Clean Architecture available for the BCA final semester reference library?',
        createdDate: '20/09/2026, 04:15 PM',
      },
    ];
  });

  // Modals & Popups
  const [selectedBookForDetails, setSelectedBookForDetails] = useState<Book | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [isDbInspectorOpen, setIsDbInspectorOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem('booknest_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('booknest_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('booknest_contacts', JSON.stringify(contactMessages));
  }, [contactMessages]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Cart Operations
  const handleAddToCart = (book: Book, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.book.bookId === book.bookId);
      if (existing) {
        return prev.map((item) =>
          item.book.bookId === book.bookId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { book, quantity }];
    });
    showToast(`Added "${book.bookName}" (${quantity}) to Cart!`);
  };

  const handleUpdateQuantity = (bookId: number, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.book.bookId === bookId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (bookId: number) => {
    setCart((prev) => prev.filter((item) => item.book.bookId !== bookId));
    showToast('Item removed from cart.');
  };

  const handleClearCart = () => {
    setCart([]);
    showToast('Cart cleared.');
  };

  // Checkout & Order Placement
  const handleOrderComplete = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCart([]);
    setIsCheckoutOpen(false);
    setCompletedOrder(newOrder);
  };

  // Contact Inquiries
  const handleSendMessage = (msg: Omit<ContactMessage, 'contactId' | 'createdDate'>) => {
    const newMsg: ContactMessage = {
      ...msg,
      contactId: contactMessages.length + 1,
      createdDate: new Date().toLocaleString('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
    };
    setContactMessages((prev) => [newMsg, ...prev]);
    showToast('Message saved to ContactMessages table!');
  };

  // Reset Database to Initial Seed
  const handleResetDatabase = () => {
    localStorage.removeItem('booknest_orders');
    localStorage.removeItem('booknest_contacts');
    localStorage.removeItem('booknest_cart');
    setCart([]);
    window.location.reload();
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 text-xs sm:text-sm font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-5">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Store & Companion Header */}
      <StoreHeader
        activePage={storePage}
        setActivePage={(page) => {
          setAppMode('store');
          setStorePage(page as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        cartCount={totalCartCount}
        appMode={appMode}
        setAppMode={(mode) => {
          setAppMode(mode);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        openDbInspector={() => setIsDbInspectorOpen(true)}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* VIEW 1: STORE MODE (The 6 Main Pages) */}
        {appMode === 'store' && (
          <>
            {storePage === 'home' && (
              <HomePage
                books={books}
                onSelectBook={(book) => setSelectedBookForDetails(book)}
                onAddToCart={(book) => handleAddToCart(book, 1)}
                onNavigate={(page, category) => {
                  if (category) {
                    setSelectedCategory(category);
                  }
                  setStorePage(page as any);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            )}

            {storePage === 'books' && (
              <BooksPage
                books={books}
                initialCategory={selectedCategory}
                onSelectBook={(book) => setSelectedBookForDetails(book)}
                onAddToCart={(book) => handleAddToCart(book, 1)}
              />
            )}

            {storePage === 'about' && (
              <AboutPage
                onNavigate={(p) => setStorePage(p as any)}
                openSourceCode={() => setAppMode('code')}
              />
            )}

            {storePage === 'contact' && (
              <ContactPage
                onSendMessage={handleSendMessage}
                openDatabaseInspector={() => setIsDbInspectorOpen(true)}
              />
            )}

            {storePage === 'cart' && (
              <CartPage
                cart={cart}
                onUpdateQuantity={handleUpdateQuantity}
                onRemoveItem={handleRemoveItem}
                onClearCart={handleClearCart}
                onNavigate={(p) => setStorePage(p as any)}
                onOpenCheckout={() => setIsCheckoutOpen(true)}
              />
            )}
          </>
        )}

        {/* VIEW 2: C# SOURCE CODE STUDIO */}
        {appMode === 'code' && <SourceCodeViewer />}

        {/* VIEW 3: VISUAL STUDIO & SQL SERVER LOCALDB GUIDE */}
        {appMode === 'vs-guide' && <VisualStudioGuide />}

        {/* VIEW 4: GIT & GITHUB SETUP GUIDE */}
        {appMode === 'github-guide' && <GitHubGuide />}

        {/* VIEW 5: COLLEGE PROJECT REPORT (20 SECTIONS) */}
        {appMode === 'report' && <ProjectReportViewer />}

        {/* VIEW 6: VIVA VOCE PREPARATION (20 QUESTIONS) */}
        {appMode === 'viva' && <VivaPreparation />}

        {/* VIEW 7: TESTING CHECKLIST (10 TEST CASES) */}
        {appMode === 'testing' && <TestingChecklistViewer />}
      </main>

      {/* Global Modals */}
      <BookDetailsModal
        book={selectedBookForDetails}
        onClose={() => setSelectedBookForDetails(null)}
        onAddToCart={(book, qty) => handleAddToCart(book, qty)}
      />

      {isCheckoutOpen && (
        <CheckoutModal
          cart={cart}
          onClose={() => setIsCheckoutOpen(false)}
          onOrderComplete={handleOrderComplete}
        />
      )}

      <OrderSuccessModal
        order={completedOrder}
        onClose={() => setCompletedOrder(null)}
        onOpenDatabase={() => setIsDbInspectorOpen(true)}
        onNavigateHome={() => {
          setCompletedOrder(null);
          setStorePage('home');
        }}
      />

      <DatabaseInspector
        isOpen={isDbInspectorOpen}
        onClose={() => setIsDbInspectorOpen(false)}
        books={books}
        contactMessages={contactMessages}
        orders={orders}
        onResetDatabase={handleResetDatabase}
      />

      {/* Store Footer */}
      <StoreFooter
        setActivePage={(page) => {
          setAppMode('store');
          setStorePage(page as any);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        openSourceCode={() => setAppMode('code')}
        openDbInspector={() => setIsDbInspectorOpen(true)}
        openGitHubGuide={() => setAppMode('github-guide')}
      />
    </div>
  );
}
