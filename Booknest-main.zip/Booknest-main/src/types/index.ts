export interface Book {
  bookId: number;
  bookName: string;
  author: string;
  category: string;
  price: number;
  description: string;
  imageUrl: string;
  stockQuantity: number;
  isbn?: string;
  rating?: number;
  publishedYear?: number;
}

export interface CartItem {
  book: Book;
  quantity: number;
}

export interface ContactMessage {
  contactId: number;
  name: string;
  email: string;
  phone: string;
  message: string;
  createdDate: string;
}

export interface OrderDetail {
  orderDetailId: number;
  orderId: number;
  bookId: number;
  bookName: string;
  quantity: number;
  price: number;
}

export interface Order {
  orderId: number;
  orderCode: string;
  customerName: string;
  email: string;
  phone: string;
  address: string;
  orderDate: string;
  totalAmount: number;
  status: 'Pending' | 'Confirmed' | 'Dispatched' | 'Delivered';
  items: OrderDetail[];
}

export interface DotNetSourceFile {
  path: string;
  name: string;
  category: 'Solution' | 'Config' | 'Model' | 'Controller' | 'View' | 'Content' | 'Database' | 'Documentation';
  language: 'csharp' | 'html' | 'xml' | 'css' | 'sql' | 'markdown' | 'text';
  description: string;
  content: string;
}

export interface VivaQuestion {
  id: number;
  question: string;
  category: string;
  answer: string;
  keyPoints?: string[];
}

export interface TestCase {
  id: number;
  testCase: string;
  module: string;
  description?: string;
  inputData?: string;
  expectedResult: string;
  status: 'Pass' | 'Fail' | 'Pending';
  remarks?: string;
}

export interface ReportSection {
  number: number;
  title: string;
  content: string;
}
