import React from 'react';
import { BookOpen, GraduationCap, CheckCircle2, Server, Layers, Cpu, Database, Code2 } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: string) => void;
  openSourceCode: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate, openSourceCode }) => {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-8 sm:p-10 shadow-lg border border-slate-800">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-3">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>Bachelor of Computer Applications (BCA) Project</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">About BookNest</h1>
        <p className="text-slate-300 text-sm sm:text-base mt-2 max-w-2xl leading-relaxed">
          BookNest is an academic online bookstore application architected on the classic ASP.NET .NET Framework MVC stack with C#, Entity Framework 6, and Microsoft SQL Server LocalDB.
        </p>
      </div>

      {/* Mission & Purpose */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Purpose of the Website</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            College libraries and students face difficulties locating specialized computer science and engineering literature. BookNest simplifies this by creating an accessible, responsive digital catalog where students can explore titles, verify real-time campus stock availability, and place simulated orders.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold">
            <GraduationCap className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Academic Mission</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Developed to fulfill the BCA mini-project criteria, BookNest demonstrates core software engineering competencies: 3-tier architectural separation (Model, View, Controller), relational database modeling, session state caching, and object-relational mapping via Entity Framework.
          </p>
        </div>
      </div>

      {/* Architectural Breakdown */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
        <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Layers className="w-5 h-5 text-amber-500" />
          <span>The MVC 3-Tier Architecture in BookNest</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-blue-600 text-white text-xs font-bold flex items-center justify-center">M</span>
              <h4 className="font-bold text-sm text-slate-900">Models (Data Layer)</h4>
            </div>
            <p className="text-xs text-slate-600">
              Entity classes including <code className="text-slate-800 font-mono">Book.cs</code>, <code className="text-slate-800 font-mono">Order.cs</code>, and <code className="text-slate-800 font-mono">ContactMessage.cs</code> decorated with Data Annotations for strict schema constraints and validation.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-emerald-600 text-white text-xs font-bold flex items-center justify-center">V</span>
              <h4 className="font-bold text-sm text-slate-900">Views (UI Layer)</h4>
            </div>
            <p className="text-xs text-slate-600">
              Razor view templates (<code className="text-slate-800 font-mono">.cshtml</code>) combined with Bootstrap 5 components and HTML5 helpers to render responsive, mobile-first pages with zero presentation clutter.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-amber-600 text-white text-xs font-bold flex items-center justify-center">C</span>
              <h4 className="font-bold text-sm text-slate-900">Controllers (Logic)</h4>
            </div>
            <p className="text-xs text-slate-600">
              Action methods handling HTTP GET/POST queries, filtering records via LINQ, manipulating session state for cart items, and persisting transactions into SQL Server.
            </p>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={openSourceCode}
            className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-2 transition"
          >
            <Code2 className="w-4 h-4 text-emerald-400" />
            <span>Inspect C# Controllers & Models Code</span>
          </button>
        </div>
      </div>

      {/* Key Features List */}
      <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-4">
        <h3 className="text-lg font-bold text-slate-900">Core Features Implemented</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm text-slate-700">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>Interactive 6-page navigation with zero broken routes.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>Real-time category filtering & dynamic substring search.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>In-memory shopping cart using ASP.NET Session state.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>Simulated checkout saving master-detail records in SQL Server.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>Validated contact feedback form saving to ContactMessages table.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
            <span>Bootstrap 5 responsive UI designed for college viva presentation.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
