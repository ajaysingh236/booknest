import React from 'react';
import { Book } from '../../types';
import { BookOpen, ArrowRight, ShieldCheck, Truck, Headphones, Sparkles, ShoppingBag, Eye, Star } from 'lucide-react';

interface HomePageProps {
  books: Book[];
  onSelectBook: (book: Book) => void;
  onAddToCart: (book: Book) => void;
  onNavigate: (page: string, category?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  books,
  onSelectBook,
  onAddToCart,
  onNavigate,
}) => {
  const featuredBooks = books.slice(0, 4);

  const categories = [
    { name: 'Programming', count: '4 Books', desc: 'C#, Java, Python & Clean Architecture' },
    { name: 'Web Development', count: '2 Books', desc: 'HTML, CSS, Modern JavaScript & Full Stack' },
    { name: 'Computer Science', count: '2 Books', desc: 'Algorithms, Data Structures & Database Concepts' },
    { name: 'Self Help', count: '2 Books', desc: 'Habit Building, Financial Psychology & Focus' },
  ];

  return (
    <div className="space-y-12">
      {/* 1. Hero / Banner Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white shadow-xl border border-slate-700/50 p-8 sm:p-12">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-400/20 text-amber-300 border border-amber-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Welcome to BookNest • College Edition</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
            Knowledge Delivered to Your <span className="text-amber-400">Desk & Lab</span>
          </h1>

          <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
            The premier online bookstore crafted for BCA, Computer Science, and Engineering students. Browse top-rated textbooks, programming classics, and self-growth essentials with instant simulated checkout.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('books')}
              className="px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm sm:text-base transition flex items-center gap-2 shadow-lg shadow-amber-400/20"
            >
              <span>Explore All Books</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('about')}
              className="px-6 py-3 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white font-medium text-sm sm:text-base transition border border-slate-600"
            >
              About Project & Architecture
            </button>
          </div>
        </div>

        {/* Decorative Graphic Element */}
        <div className="hidden lg:block absolute right-12 top-1/2 -translate-y-1/2 opacity-20 pointer-events-none">
          <BookOpen className="w-96 h-96 text-white" />
        </div>
      </section>

      {/* 2. Key Value Pillars */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm flex items-start gap-3.5">
          <div className="p-2.5 rounded-lg bg-blue-50 text-blue-600">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Free Campus Delivery</h4>
            <p className="text-xs text-slate-500 mt-0.5">Complimentary shipping across campus & hostel libraries.</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm flex items-start gap-3.5">
          <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Curated Academic Editions</h4>
            <p className="text-xs text-slate-500 mt-0.5">Recommended by BCA, B.Tech, and MCA professors.</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm flex items-start gap-3.5">
          <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Instant Simulated Orders</h4>
            <p className="text-xs text-slate-500 mt-0.5">Complete checkout simulated with SQL Server persistence.</p>
          </div>
        </div>
      </section>

      {/* 3. Browse By Category */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Popular Categories</h2>
            <p className="text-xs sm:text-sm text-slate-500">Pick a domain to filter textbooks and references</p>
          </div>
          <button
            onClick={() => onNavigate('books')}
            className="text-xs sm:text-sm font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>All Categories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.name}
              onClick={() => onNavigate('books', cat.name)}
              className="p-5 rounded-xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-md transition cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 group-hover:bg-amber-100 group-hover:text-amber-800 transition">
                  {cat.count}
                </span>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-500 group-hover:translate-x-1 transition" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-amber-600 transition text-base">{cat.name}</h3>
              <p className="text-xs text-slate-500 mt-1 line-clamp-1">{cat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Featured Books Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="inline-flex items-center gap-1 text-xs font-semibold text-amber-600 mb-1">
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span>Recommended by College Faculty</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Featured Books</h2>
          </div>
          <button
            onClick={() => onNavigate('books')}
            className="text-xs sm:text-sm font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>View Full Catalog ({books.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredBooks.map((book) => (
            <div
              key={book.bookId}
              className="bg-white rounded-xl border border-slate-200/90 shadow-sm hover:shadow-md transition flex flex-col overflow-hidden group"
            >
              {/* Book Cover Image */}
              <div className="relative h-56 bg-slate-100 overflow-hidden cursor-pointer" onClick={() => onSelectBook(book)}>
                <img
                  src={book.imageUrl}
                  alt={book.bookName}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-900/80 text-white backdrop-blur-sm">
                  {book.category}
                </span>
                {book.stockQuantity > 0 ? (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/90 text-white backdrop-blur-sm">
                    In Stock
                  </span>
                ) : (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-500/90 text-white backdrop-blur-sm">
                    Out of Stock
                  </span>
                )}
              </div>

              {/* Book Body */}
              <div className="p-4 flex flex-col flex-1">
                <h3
                  onClick={() => onSelectBook(book)}
                  className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 cursor-pointer hover:text-indigo-600 transition"
                  title={book.bookName}
                >
                  {book.bookName}
                </h3>
                <p className="text-xs text-slate-500 mt-1">By <span className="font-medium text-slate-700">{book.author}</span></p>

                <div className="mt-auto pt-4 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">Price</span>
                    <span className="text-lg font-bold text-slate-950">₹{book.price}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onSelectBook(book)}
                      className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                      title="View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onAddToCart(book)}
                      disabled={book.stockQuantity <= 0}
                      className="px-3 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Call to Action Banner */}
      <section className="bg-amber-50 border border-amber-200/80 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-xl font-bold text-slate-900">Need specific textbooks for your BCA semester?</h3>
          <p className="text-sm text-slate-600 max-w-xl">
            Drop us an inquiry through the Contact page or browse our complete library. All simulated orders are recorded into SQL Server LocalDB.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('contact')}
            className="px-5 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition"
          >
            Contact Helpdesk
          </button>
          <button
            onClick={() => onNavigate('books')}
            className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-sm font-bold transition"
          >
            View All Books
          </button>
        </div>
      </section>
    </div>
  );
};
