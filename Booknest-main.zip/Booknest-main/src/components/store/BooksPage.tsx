import React, { useState, useMemo } from 'react';
import { Book } from '../../types';
import { Search, Filter, ShoppingBag, Eye, X, BookOpen } from 'lucide-react';
import { BOOK_CATEGORIES } from '../../data/sampleBooks';

interface BooksPageProps {
  books: Book[];
  onSelectBook: (book: Book) => void;
  onAddToCart: (book: Book) => void;
  initialCategory?: string;
}

export const BooksPage: React.FC<BooksPageProps> = ({
  books,
  onSelectBook,
  onAddToCart,
  initialCategory = 'All',
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'default' | 'price-low' | 'price-high' | 'rating'>('default');

  const filteredBooks = useMemo(() => {
    let result = books.filter((book) => {
      const matchesCategory =
        selectedCategory === 'All' || book.category.toLowerCase() === selectedCategory.toLowerCase();
      const matchesSearch =
        book.bookName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        book.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });

    if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }

    return result;
  }, [books, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-7 h-7 text-amber-500" />
            <span>Books & Products Catalog</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Displaying {filteredBooks.length} of {books.length} books from <code className="text-xs font-mono bg-slate-100 text-slate-700 px-1 py-0.5 rounded">BookNestDB.Books</code>
          </p>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by title, author..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-9 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-400 text-sm bg-white"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Filter and Sort Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200/80 shadow-sm">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" />
            Category:
          </span>
          {BOOK_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-amber-400 shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Sort By:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-amber-400 text-xs"
          >
            <option value="default">Default Order</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Empty State */}
      {filteredBooks.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <BookOpen className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-800">No books found</h3>
            <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
              No titles match your current search query "{searchQuery}" or category filter "{selectedCategory}".
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
            }}
            className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        /* Books Grid (Bootstrap Card Style) */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredBooks.map((book) => (
            <div
              key={book.bookId}
              className="bg-white rounded-xl border border-slate-200/90 shadow-sm hover:shadow-md transition flex flex-col overflow-hidden group"
            >
              {/* Cover Image */}
              <div className="relative h-60 bg-slate-100 overflow-hidden cursor-pointer" onClick={() => onSelectBook(book)}>
                <img
                  src={book.imageUrl}
                  alt={book.bookName}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded text-[11px] font-semibold bg-slate-900/80 text-white backdrop-blur-sm">
                  {book.category}
                </span>
                {book.stockQuantity > 0 ? (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/90 text-white backdrop-blur-sm">
                    {book.stockQuantity} in stock
                  </span>
                ) : (
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-500/90 text-white backdrop-blur-sm">
                    Out of Stock
                  </span>
                )}
              </div>

              {/* Card Body */}
              <div className="p-4 flex flex-col flex-1">
                <h3
                  onClick={() => onSelectBook(book)}
                  className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 cursor-pointer hover:text-indigo-600 transition"
                  title={book.bookName}
                >
                  {book.bookName}
                </h3>
                <p className="text-xs text-slate-500 mt-1">By <span className="font-medium text-slate-700">{book.author}</span></p>

                <p className="text-xs text-slate-600 line-clamp-2 mt-2 leading-relaxed">
                  {book.description}
                </p>

                <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Price</span>
                    <span className="text-lg font-bold text-slate-950">₹{book.price}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onSelectBook(book)}
                      className="px-2.5 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium transition flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </button>
                    <button
                      onClick={() => onAddToCart(book)}
                      disabled={book.stockQuantity <= 0}
                      className="px-3 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
