import React from 'react';
import { Order } from '../../types';
import { CheckCircle2, ArrowRight, Database, Receipt, MapPin, Calendar, User } from 'lucide-react';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  onOpenDatabase: () => void;
  onNavigateHome: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  onOpenDatabase,
  onNavigateHome,
}) => {
  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Success Banner */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm text-white flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h3 className="text-2xl font-extrabold tracking-tight">Order Confirmed!</h3>
          <p className="text-xs text-emerald-100 mt-1">
            Transaction committed to <code className="font-mono bg-emerald-800/60 px-1.5 py-0.5 rounded text-white">BookNestDB.Orders</code>
          </p>
        </div>

        {/* Order Details Body */}
        <div className="p-6 space-y-5">
          <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Order Code</span>
              <span className="text-base font-extrabold text-indigo-600 font-mono">{order.orderCode}</span>
            </div>
            <div className="text-right">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Status</span>
              <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                {order.status}
              </span>
            </div>
          </div>

          {/* Customer Metadata */}
          <div className="space-y-2 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-slate-400" />
              <span>Customer: <strong className="text-slate-800">{order.customerName}</strong> ({order.email} • {order.phone})</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Order Date: <strong className="text-slate-800">{order.orderDate}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-slate-400" />
              <span>Delivering to: <strong className="text-slate-800">{order.address}</strong></span>
            </div>
          </div>

          {/* Purchased Items List */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Receipt className="w-3.5 h-3.5" />
              <span>Purchased Line Items ({order.items.length})</span>
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-xl overflow-hidden max-h-44 overflow-y-auto">
              {order.items.map((item) => (
                <div key={item.orderDetailId} className="p-3 text-xs flex justify-between items-center bg-white hover:bg-slate-50">
                  <div>
                    <p className="font-semibold text-slate-800">{item.bookName}</p>
                    <p className="text-slate-400 text-[11px]">Qty: {item.quantity} × ₹{item.price}</p>
                  </div>
                  <span className="font-bold text-slate-900">₹{item.quantity * item.price}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Grand Total */}
          <div className="pt-2 flex justify-between items-center border-t border-slate-100">
            <span className="text-sm font-semibold text-slate-600">Total Charged</span>
            <span className="text-2xl font-extrabold text-slate-950">₹{order.totalAmount}</span>
          </div>

          {/* Actions */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
            <button
              onClick={() => {
                onClose();
                onOpenDatabase();
              }}
              className="flex-1 py-2.5 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-400 text-xs font-bold transition flex items-center justify-center gap-2 border border-slate-700 shadow-sm"
            >
              <Database className="w-4 h-4" />
              <span>View in SQL Database Inspector</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onNavigateHome();
              }}
              className="py-2.5 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
            >
              <span>Back to Store</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
