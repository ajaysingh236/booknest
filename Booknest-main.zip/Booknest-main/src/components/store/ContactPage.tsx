import React, { useState } from 'react';
import { ContactMessage } from '../../types';
import { Mail, Phone, MapPin, Send, CheckCircle2, User, MessageSquare, Database, AlertCircle } from 'lucide-react';

interface ContactPageProps {
  onSendMessage: (msg: Omit<ContactMessage, 'contactId' | 'createdDate'>) => void;
  openDatabaseInspector: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  onSendMessage,
  openDatabaseInspector,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Full name is required';
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) errs.email = 'Valid email address is required';
    if (!phone.trim() || !/^\d{10}$/.test(phone.replace(/\D/g, ''))) errs.phone = '10-digit mobile number is required';
    if (!message.trim() || message.trim().length < 10) errs.message = 'Message must be at least 10 characters long';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSendMessage({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      message: message.trim(),
    });

    setSubmitted(true);
    setName('');
    setEmail('');
    setPhone('');
    setMessage('');
    setErrors({});
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
          <Mail className="w-7 h-7 text-amber-500" />
          <span>Contact Us & Student Inquiries</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Have an inquiry about academic book availability or the BCA project? Drop a message below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/90 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-base font-bold text-slate-900">Send an Inquiry</h3>
            <span className="text-[11px] text-slate-400 font-mono">BookNestDB.ContactMessages</span>
          </div>

          {submitted && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex flex-col gap-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Message saved to SQL Server ContactMessages table!</span>
              </div>
              <p className="text-emerald-700 text-xs">
                Our support team and project guide have received your note. You can verify this record directly in the SQL database explorer.
              </p>
              <div className="pt-1">
                <button
                  onClick={openDatabaseInspector}
                  className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Inspect in SQL Database Explorer</span>
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>Your Name *</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Priya Sharma"
                className={`w-full px-3.5 py-2 rounded-lg border text-sm focus:outline-none focus:ring-2 ${
                  errors.name ? 'border-rose-400 focus:ring-rose-400 bg-rose-50/30' : 'border-slate-300 focus:ring-amber-400'
                }`}
              />
              {errors.name && <p className="text-xs text-rose-500 mt-1">{errors.name}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>Email Address *</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="priya@college.edu.in"
                  className={`w-full px-3.5 py-2 rounded-lg border text-sm focus:outline-none focus:ring-2 ${
                    errors.email ? 'border-rose-400 focus:ring-rose-400 bg-rose-50/30' : 'border-slate-300 focus:ring-amber-400'
                  }`}
                />
                {errors.email && <p className="text-xs text-rose-500 mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>Phone Number (10 Digits) *</span>
                </label>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="9876543210"
                  className={`w-full px-3.5 py-2 rounded-lg border text-sm focus:outline-none focus:ring-2 ${
                    errors.phone ? 'border-rose-400 focus:ring-rose-400 bg-rose-50/30' : 'border-slate-300 focus:ring-amber-400'
                  }`}
                />
                {errors.phone && <p className="text-xs text-rose-500 mt-1">{errors.phone}</p>}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                <span>Message / Feedback *</span>
              </label>
              <textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your book inquiry or questions here..."
                className={`w-full px-3.5 py-2 rounded-lg border text-sm focus:outline-none focus:ring-2 ${
                  errors.message ? 'border-rose-400 focus:ring-rose-400 bg-rose-50/30' : 'border-slate-300 focus:ring-amber-400'
                }`}
              />
              {errors.message && <p className="text-xs text-rose-500 mt-1">{errors.message}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm transition flex items-center justify-center gap-2 shadow-md shadow-amber-400/20"
            >
              <Send className="w-4 h-4" />
              <span>Submit Message (Save to SQL Server)</span>
            </button>
          </form>
        </div>

        {/* Store & College Information */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              Store & College Location
            </h3>

            <div className="space-y-4 text-xs sm:text-sm text-slate-600">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600 flex-shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">Campus Store Address</h5>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    Department of Computer Applications (BCA Block), College Campus, Knowledge Park, India
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 flex-shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">Student Helpline</h5>
                  <p className="text-xs text-slate-500 mt-0.5">+91 98765 43210 (Mon-Sat, 9 AM - 5 PM)</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600 flex-shrink-0 mt-0.5">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">Official Email</h5>
                  <p className="text-xs text-slate-500 mt-0.5">support@booknest-bca.edu.in</p>
                </div>
              </div>
            </div>
          </div>

          {/* BCA Viva Explanation Box */}
          <div className="bg-slate-900 text-slate-300 p-5 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
              <AlertCircle className="w-4 h-4" />
              <span>BCA Viva Insight</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              In ASP.NET MVC, the <code className="text-amber-300 font-mono">ContactController.cs</code> validates the <code className="text-amber-300 font-mono">ContactMessage</code> model using Data Annotations (<code>[Required]</code>, <code>[EmailAddress]</code>, <code>[RegularExpression]</code>). If valid, it writes directly to SQL Server via <code className="text-amber-300 font-mono">_db.SaveChanges()</code>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
