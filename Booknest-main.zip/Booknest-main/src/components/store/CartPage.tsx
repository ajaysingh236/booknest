import React from 'react';
import { CartItem } from '../../types';
import { Trash2, Plus, Minus, ArrowRight, ArrowLeft, ShoppingBag, ShieldCheck, BookOpen } from 'lucide-react';

interface CartPageProps {
  cart: CartItem[];
  onUpdateQuantity: (bookId: number, delta: number) => void;
  onRemoveItem: (bookId: number) => void;
  onClearCart: () => void;
  onNavigate: (page: string) => void;
  onOpenCheckout: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onNavigate,
  onOpenCheckout,
}) => {
  const grandTotal = cart.reduce((sum, item) => sum + item.book.price * item.quantity, 0);
  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-2xl mx-auto space-y-4 shadow-sm">
        <div className="w-20 h-20 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center mx-auto">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">Your Shopping Cart is Empty</h2>
        <p className="text-sm text-slate-500 max-w-md mx-auto">
          You haven't added any books yet. Explore our academic and programming collection and start building your library!
        </p>
        <div className="pt-2">
          <button
            onClick={() => onNavigate('books')}
            className="px-6 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm transition shadow-md shadow-amber-400/20 inline-flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Browse Books Catalog</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-7 h-7 text-amber-500" />
            <span>Shopping Cart ({totalItemCount} items)</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Simulated in-process state managed via <code className="text-xs font-mono bg-slate-100 text-slate-700 px-1 py-0.5 rounded">Session["Cart"]</code> in ASP.NET MVC
          </p>
        </div>

        <button
          onClick={onClearCart}
          className="text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-3 py-1.5 rounded-lg transition border border-rose-200"
        >
          Clear Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Cart Items Table */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden">
            <div className="divide-y divide-slate-100">
              {cart.map((item) => (
                <div key={item.book.bookId} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition">
                  {/* Book Info */}
                  <div className="flex items-center gap-4 flex-1">
                    <img
                      src={item.book.imageUrl}
                      alt={item.book.bookName}
                      className="w-16 h-20 object-cover rounded-md border border-slate-200 flex-shrink-0 shadow-xs"
                    />
                    <div>
                      <span className="text-[11px] font-semibold text-amber-600 uppercase tracking-wide">
                        {item.book.category}
                      </span>
                      <h4 className="font-bold text-slate-900 text-sm leading-snug line-clamp-1">
                        {item.book.bookName}
                      </h4>
                      <p className="text-xs text-slate-500">By {item.book.author}</p>
                      <p className="text-xs font-bold text-slate-700 mt-1">
                        ₹{item.book.price} <span className="font-normal text-slate-400">each</span>
                      </p>
                    </div>
                  </div>

                  {/* Quantity and Subtotal */}
                  <div className="flex items-center justify-between sm:justify-end gap-6 pt-2 sm:pt-0 border-t sm:border-0 border-slate-100">
                    {/* Quantity Selector */}
                    <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white shadow-2xs">
                      <button
                        onClick={() => onUpdateQuantity(item.book.bookId, -1)}
                        className="p-1.5 text-slate-600 hover:bg-slate-100 transition"
                        title="Decrease"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-bold text-slate-800 min-w-[28px] text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.book.bookId, 1)}
                        className="p-1.5 text-slate-600 hover:bg-slate-100 transition"
                        title="Increase"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Line Total */}
                    <div className="text-right min-w-[70px]">
                      <span className="text-xs text-slate-400 block text-right">Subtotal</span>
                      <span className="text-base font-extrabold text-slate-900">
                        ₹{item.book.price * item.quantity}
                      </span>
                    </div>

                    {/* Delete Item */}
                    <button
                      onClick={() => onRemoveItem(item.book.bookId)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                      title="Remove from Cart"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => onNavigate('books')}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Continue Shopping</span>
            </button>
            <span className="text-xs text-slate-400">
              Tax calculated at simulated checkout
            </span>
          </div>
        </div>

        {/* Order Summary Card */}
        <div className="lg:col-span-4">
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6 space-y-5 sticky top-24">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              Order Summary
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal ({totalItemCount} items)</span>
                <span className="font-semibold text-slate-800">₹{grandTotal}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Standard Delivery</span>
                <span className="font-semibold text-emerald-600">FREE</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Student Discount</span>
                <span className="font-semibold text-emerald-600">-₹0 (Applied)</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-500 block">Grand Total</span>
                <span className="text-2xl font-extrabold text-slate-950">₹{grandTotal}</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-400 bg-slate-100 px-2 py-1 rounded">
                INR (₹)
              </span>
            </div>

            <button
              onClick={onOpenCheckout}
              className="w-full py-3 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200/60 text-[11px] text-slate-500 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <span>
                Simulated checkout for BCA project evaluation. Upon confirmation, records will be saved into the <code className="font-mono text-slate-700">Orders</code> and <code className="font-mono text-slate-700">OrderDetails</code> SQL tables.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
