import React from 'react';
import { BookOpen, GraduationCap, Github, Database, Code, CheckCircle2 } from 'lucide-react';

interface StoreFooterProps {
  setActivePage: (page: string) => void;
  openSourceCode: () => void;
  openDbInspector: () => void;
  openGitHubGuide: () => void;
}

export const StoreFooter: React.FC<StoreFooterProps> = ({
  setActivePage,
  openSourceCode,
  openDbInspector,
  openGitHubGuide,
}) => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 text-slate-300 pt-12 pb-8 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand & Concept */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 font-bold">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">BookNest</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Online Book Store developed as an ASP.NET .NET Framework MVC Mini Project for BCA examination & viva submission.
            </p>
            <div className="inline-flex items-center gap-1.5 text-xs text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-full border border-amber-400/20">
              <GraduationCap className="w-3.5 h-3.5" />
              BCA Mini Project Viva Ready
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Website Pages</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => setActivePage('home')} className="hover:text-amber-400 transition">
                  Home Page
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('books')} className="hover:text-amber-400 transition">
                  Books & Products Catalog
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('about')} className="hover:text-amber-400 transition">
                  About Us (Project Info)
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('contact')} className="hover:text-amber-400 transition">
                  Contact Us (Feedback Form)
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('cart')} className="hover:text-amber-400 transition">
                  Shopping Cart & Checkout
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Academic & Architecture */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Technical Stack</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>ASP.NET MVC 5 (.NET 4.8)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>C# Object Oriented Logic</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Entity Framework 6 ORM</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>SQL Server LocalDB (BookNestDB)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Bootstrap 5 & Razor Views</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Project Companion Tools */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Project Companion</h4>
            <div className="space-y-2">
              <button
                onClick={openSourceCode}
                className="w-full text-left px-3 py-2 rounded bg-slate-800/80 hover:bg-slate-800 text-xs text-slate-300 hover:text-emerald-400 flex items-center justify-between transition border border-slate-700/50"
              >
                <span className="flex items-center gap-2">
                  <Code className="w-3.5 h-3.5 text-emerald-400" />
                  C# Source Code Studio
                </span>
                <span className="text-[10px] bg-slate-700 px-1.5 py-0.5 rounded text-slate-300">27 Files</span>
              </button>

              <button
                onClick={openDbInspector}
                className="w-full text-left px-3 py-2 rounded bg-slate-800/80 hover:bg-slate-800 text-xs text-slate-300 hover:text-cyan-400 flex items-center justify-between transition border border-slate-700/50"
              >
                <span className="flex items-center gap-2">
                  <Database className="w-3.5 h-3.5 text-cyan-400" />
                  SQL LocalDB Tables
                </span>
                <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-1.5 py-0.5 rounded">4 Tables</span>
              </button>

              <button
                onClick={openGitHubGuide}
                className="w-full text-left px-3 py-2 rounded bg-slate-800/80 hover:bg-slate-800 text-xs text-slate-300 hover:text-amber-400 flex items-center justify-between transition border border-slate-700/50"
              >
                <span className="flex items-center gap-2">
                  <Github className="w-3.5 h-3.5 text-amber-400" />
                  GitHub Repository Setup
                </span>
                <span className="text-[10px] bg-slate-700 px-1.5 py-0.5 rounded text-slate-300">Guide</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© {new Date().getFullYear()} BookNest – Online Book Store. Prepared for BCA Academic Mini-Project Submission.</p>
          <div className="flex items-center gap-4">
            <span>Visual Studio Solution: BookNest.sln</span>
            <span>•</span>
            <span>Database: BookNestDB</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
