import React, { useState } from 'react';
import {
  BookOpen,
  ShoppingBag,
  Home,
  Grid,
  Info,
  Mail,
  Database,
  FileCode,
  GraduationCap,
  FileText,
  CheckSquare,
  Github,
  Monitor,
  Download,
  Check,
} from 'lucide-react';
import { generateAndDownloadProjectZip } from '../../services/zipExporter';

export type AppMode = 'store' | 'code' | 'vs-guide' | 'github-guide' | 'report' | 'viva' | 'testing';

interface StoreHeaderProps {
  activePage: string;
  setActivePage: (page: string) => void;
  cartCount: number;
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  openDbInspector: () => void;
}

export const StoreHeader: React.FC<StoreHeaderProps> = ({
  activePage,
  setActivePage,
  cartCount,
  appMode,
  setAppMode,
  openDbInspector,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      await generateAndDownloadProjectZip();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    } catch (err) {
      console.error('Download failed:', err);
      // Direct link fallback
      const link = document.createElement('a');
      link.href = '/BookNest-ASP.NET-MVC-Project.zip';
      link.download = 'BookNest-ASP.NET-MVC-Project.zip';
      link.click();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top Banner with BCA College Tag & Fast Tools */}
      <div className="bg-slate-950 px-4 py-1.5 text-xs border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-slate-400">
          <span className="inline-flex items-center gap-1 font-semibold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
            <GraduationCap className="w-3.5 h-3.5" />
            BCA Mini Project
          </span>
          <span className="hidden sm:inline">ASP.NET MVC (.NET Framework 4.8) • C# • SQL Server LocalDB</span>
        </div>

        {/* Quick Academic Navigation Bar */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setAppMode('store')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'store' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Home className="w-3 h-3" />
            <span>Storefront</span>
          </button>

          <button
            onClick={() => setAppMode('code')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'code' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-emerald-400 hover:bg-slate-800'
            }`}
            title="Inspect 27 C# & Razor Project Files"
          >
            <FileCode className="w-3 h-3 text-emerald-400" />
            <span>C# Code</span>
          </button>

          <button
            onClick={() => setAppMode('vs-guide')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'vs-guide' ? 'bg-blue-500 text-white font-bold' : 'text-slate-300 hover:text-blue-400 hover:bg-slate-800'
            }`}
            title="Visual Studio & LocalDB Setup Guide"
          >
            <Monitor className="w-3 h-3 text-blue-400" />
            <span>VS Guide</span>
          </button>

          <button
            onClick={() => setAppMode('github-guide')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'github-guide' ? 'bg-slate-700 text-amber-300 font-bold' : 'text-slate-300 hover:text-amber-300 hover:bg-slate-800'
            }`}
            title="Git & GitHub Setup + README"
          >
            <Github className="w-3 h-3 text-amber-400" />
            <span>GitHub</span>
          </button>

          <button
            onClick={() => setAppMode('report')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'report' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-300 hover:text-indigo-400 hover:bg-slate-800'
            }`}
            title="20 College Project Report Sections"
          >
            <FileText className="w-3 h-3 text-indigo-400" />
            <span>Report (20 Sec)</span>
          </button>

          <button
            onClick={() => setAppMode('viva')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'viva' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-300 hover:text-amber-400 hover:bg-slate-800'
            }`}
            title="20 BCA Viva Questions & Answers"
          >
            <GraduationCap className="w-3 h-3 text-amber-400" />
            <span>Viva (20 Q&A)</span>
          </button>

          <button
            onClick={() => setAppMode('testing')}
            className={`px-2 py-0.5 rounded text-xs transition flex items-center gap-1 ${
              appMode === 'testing' ? 'bg-teal-600 text-white font-bold' : 'text-slate-300 hover:text-teal-400 hover:bg-slate-800'
            }`}
            title="Testing Checklist (10 Test Cases)"
          >
            <CheckSquare className="w-3 h-3 text-teal-400" />
            <span>Testing</span>
          </button>

          <button
            onClick={openDbInspector}
            className="flex items-center gap-1 text-cyan-400 hover:bg-cyan-950/60 px-2 py-0.5 rounded transition border border-cyan-800/60 ml-1 font-semibold"
            title="Inspect BookNestDB SQL Server tables live"
          >
            <Database className="w-3 h-3 text-cyan-400" />
            <span>SQL DB</span>
          </button>
        </div>
      </div>

      {/* Main ASP.NET MVC Style Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo / Brand */}
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => {
              setAppMode('store');
              setActivePage('home');
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 shadow-md">
              <BookOpen className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-tight text-white">BookNest</span>
                <span className="text-xs font-medium px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-mono">MVC</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-none">Online Book Store</p>
            </div>
          </div>

          {/* Navigation Links for Store */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => {
                setAppMode('store');
                setActivePage('home');
              }}
              className={`px-3.5 py-2 rounded-md text-sm font-medium transition flex items-center gap-1.5 ${
                appMode === 'store' && activePage === 'home'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Home className="w-4 h-4" />
              Home
            </button>

            <button
              onClick={() => {
                setAppMode('store');
                setActivePage('books');
              }}
              className={`px-3.5 py-2 rounded-md text-sm font-medium transition flex items-center gap-1.5 ${
                appMode === 'store' && activePage === 'books'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Grid className="w-4 h-4" />
              Books Catalog
            </button>

            <button
              onClick={() => {
                setAppMode('store');
                setActivePage('about');
              }}
              className={`px-3.5 py-2 rounded-md text-sm font-medium transition flex items-center gap-1.5 ${
                appMode === 'store' && activePage === 'about'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Info className="w-4 h-4" />
              About Us
            </button>

            <button
              onClick={() => {
                setAppMode('store');
                setActivePage('contact');
              }}
              className={`px-3.5 py-2 rounded-md text-sm font-medium transition flex items-center gap-1.5 ${
                appMode === 'store' && activePage === 'contact'
                  ? 'bg-slate-800 text-amber-400'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Mail className="w-4 h-4" />
              Contact Us
            </button>
          </nav>

          {/* Right Action: Download ZIP + Cart Button */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={handleDownloadZip}
              disabled={downloading}
              className={`px-3 sm:px-4 py-2 rounded-lg font-semibold text-xs sm:text-sm transition flex items-center gap-1.5 sm:gap-2 border shadow-sm ${
                downloadSuccess
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white border-emerald-500'
              }`}
              title="Download full C# ASP.NET MVC Solution as .ZIP file"
            >
              {downloadSuccess ? (
                <Check className="w-4 h-4 text-white" />
              ) : (
                <Download className={`w-4 h-4 ${downloading ? 'animate-bounce' : ''}`} />
              )}
              <span className="hidden xs:inline">{downloading ? 'Preparing...' : downloadSuccess ? 'Downloaded!' : 'Download ZIP'}</span>
              <span className="xs:hidden">ZIP</span>
            </button>

            <button
              onClick={() => {
                setAppMode('store');
                setActivePage('cart');
              }}
              className={`relative px-3.5 sm:px-4 py-2 rounded-lg font-semibold text-xs sm:text-sm transition flex items-center gap-2 border ${
                appMode === 'store' && activePage === 'cart'
                  ? 'bg-amber-400 text-slate-950 border-amber-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-400 border-slate-700'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Cart</span>
              {cartCount > 0 && (
                <span className="ml-0.5 sm:ml-1 px-1.5 py-0.5 text-xs font-bold rounded-full bg-rose-600 text-white animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Nav Row */}
        <div className="flex md:hidden items-center justify-around py-2.5 border-t border-slate-800 text-xs">
          <button
            onClick={() => {
              setAppMode('store');
              setActivePage('home');
            }}
            className={`py-1 px-2 rounded ${appMode === 'store' && activePage === 'home' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Home
          </button>
          <button
            onClick={() => {
              setAppMode('store');
              setActivePage('books');
            }}
            className={`py-1 px-2 rounded ${appMode === 'store' && activePage === 'books' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Books
          </button>
          <button
            onClick={() => {
              setAppMode('store');
              setActivePage('about');
            }}
            className={`py-1 px-2 rounded ${appMode === 'store' && activePage === 'about' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            About
          </button>
          <button
            onClick={() => {
              setAppMode('store');
              setActivePage('contact');
            }}
            className={`py-1 px-2 rounded ${appMode === 'store' && activePage === 'contact' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Contact
          </button>
          <button
            onClick={() => {
              setAppMode('store');
              setActivePage('cart');
            }}
            className={`py-1 px-2 rounded ${appMode === 'store' && activePage === 'cart' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Cart ({cartCount})
          </button>
        </div>
      </div>
    </header>
  );
};
