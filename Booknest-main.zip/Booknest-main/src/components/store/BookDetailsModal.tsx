import React, { useState } from 'react';
import { Book } from '../../types';
import { X, ShoppingBag, CheckCircle2, AlertCircle, Star, ArrowLeft } from 'lucide-react';

interface BookDetailsModalProps {
  book: Book | null;
  onClose: () => void;
  onAddToCart: (book: Book, quantity: number) => void;
}

export const BookDetailsModal: React.FC<BookDetailsModalProps> = ({
  book,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState<number>(1);

  if (!book) return null;

  const handleAdd = () => {
    onAddToCart(book, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <span>Books / Details</span>
            <span>•</span>
            <span className="text-slate-800 font-mono">BookId: {book.bookId}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 grid grid-cols-1 sm:grid-cols-12 gap-8">
          {/* Left Column: Book Image */}
          <div className="sm:col-span-5 flex flex-col items-center">
            <div className="relative rounded-xl overflow-hidden shadow-lg border border-slate-200 w-full max-w-[260px] aspect-[3/4] bg-slate-100">
              <img
                src={book.imageUrl}
                alt={book.bookName}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded text-xs font-semibold bg-slate-900/80 text-white backdrop-blur-sm">
                {book.category}
              </span>
            </div>

            {book.rating && (
              <div className="flex items-center gap-1 mt-4 text-xs font-semibold text-slate-600">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{book.rating} / 5.0 Rating</span>
                <span className="text-slate-400">• Verified Academic</span>
              </div>
            )}
          </div>

          {/* Right Column: Book Details */}
          <div className="sm:col-span-7 flex flex-col justify-between space-y-4">
            <div>
              <div className="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 mb-2">
                {book.category}
              </div>

              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                {book.bookName}
              </h2>

              <p className="text-sm text-slate-600 mt-1">
                Authored by <span className="font-semibold text-slate-800">{book.author}</span>
              </p>

              {/* Price */}
              <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 block">Student Price</span>
                  <span className="text-2xl font-extrabold text-slate-950">₹{book.price}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-emerald-600 font-semibold block">In Stock & Verified</span>
                  <span className="text-[11px] text-slate-400">Inclusive of all college taxes</span>
                </div>
              </div>

              {/* Stock and Availability */}
              <div className="mt-3 flex items-center gap-2 text-xs">
                {book.stockQuantity > 0 ? (
                  <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-600">
                    <CheckCircle2 className="w-4 h-4" />
                    Available ({book.stockQuantity} copies in campus warehouse)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 font-semibold text-rose-600">
                    <AlertCircle className="w-4 h-4" />
                    Currently Out of Stock
                  </span>
                )}
              </div>

              {/* Description */}
              <div className="mt-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">Book Summary:</h4>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-h-40 overflow-y-auto pr-1">
                  {book.description}
                </p>
              </div>

              {/* Extra Metadata */}
              {book.isbn && (
                <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-slate-500 bg-slate-50 p-2 rounded-lg">
                  <div><strong className="text-slate-700">ISBN:</strong> {book.isbn}</div>
                  <div><strong className="text-slate-700">Published:</strong> {book.publishedYear || 'Recent'}</div>
                </div>
              )}
            </div>

            {/* Actions: Quantity Selector & Add to Cart */}
            <div className="pt-4 border-t border-slate-100 flex items-center gap-3">
              <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 transition font-bold"
                >
                  -
                </button>
                <span className="px-3 py-2 text-sm font-semibold text-slate-800 min-w-[36px] text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(Math.min(book.stockQuantity, quantity + 1))}
                  disabled={quantity >= book.stockQuantity}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 transition font-bold disabled:opacity-30"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAdd}
                disabled={book.stockQuantity <= 0}
                className="flex-1 py-2.5 px-4 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm transition flex items-center justify-center gap-2 shadow-md shadow-amber-400/20 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add {quantity} to Cart (₹{book.price * quantity})</span>
              </button>

              <button
                onClick={onClose}
                className="p-2.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 transition"
                title="Back to Catalog"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
