import React, { useState } from 'react';
import { Book, ContactMessage, Order, OrderDetail } from '../../types';
import { Database, Table, X, RefreshCw, Copy, Check, Terminal, ExternalLink } from 'lucide-react';

interface DatabaseInspectorProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  contactMessages: ContactMessage[];
  orders: Order[];
  onResetDatabase: () => void;
}

export const DatabaseInspector: React.FC<DatabaseInspectorProps> = ({
  isOpen,
  onClose,
  books,
  contactMessages,
  orders,
  onResetDatabase,
}) => {
  const [activeTable, setActiveTable] = useState<'Books' | 'ContactMessages' | 'Orders' | 'OrderDetails'>('Books');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Flatten all order details for the OrderDetails table view
  const allOrderDetails: OrderDetail[] = orders.flatMap((o) => o.items);

  const copyConnectionString = () => {
    navigator.clipboard.writeText(
      'Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=BookNestDB;Integrated Security=True'
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200 text-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-400 flex items-center justify-center font-bold">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base">BookNestDB — SQL Server LocalDB Explorer</h3>
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded">
                  (LocalDb)\MSSQLLocalDB
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Live relational database state for BookNest ASP.NET MVC Mini Project
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyConnectionString}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 flex items-center gap-1.5 transition border border-slate-700"
              title="Copy SQL Server Connection String for Web.config"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'Copied String!' : 'Copy ConnStr'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Table Selector Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-950/60 border-b border-slate-800 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTable('Books')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-2 ${
              activeTable === 'Books'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>dbo.Books ({books.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('ContactMessages')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-2 ${
              activeTable === 'ContactMessages'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>dbo.ContactMessages ({contactMessages.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('Orders')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-2 ${
              activeTable === 'Orders'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>dbo.Orders ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('OrderDetails')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-2 ${
              activeTable === 'OrderDetails'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>dbo.OrderDetails ({allOrderDetails.length})</span>
          </button>

          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={onResetDatabase}
              className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition px-2 py-1 rounded hover:bg-slate-800"
              title="Reset tables to default seed state"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset to Seed Data</span>
            </button>
          </div>
        </div>

        {/* Table Content Area */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs">
          {activeTable === 'Books' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider bg-slate-950/40">
                    <th className="p-2.5">BookId (PK)</th>
                    <th className="p-2.5">BookName</th>
                    <th className="p-2.5">Author</th>
                    <th className="p-2.5">Category</th>
                    <th className="p-2.5">Price</th>
                    <th className="p-2.5">StockQuantity</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {books.map((b) => (
                    <tr key={b.bookId} className="hover:bg-slate-800/40 text-slate-300">
                      <td className="p-2.5 text-cyan-400 font-bold">{b.bookId}</td>
                      <td className="p-2.5 text-white font-medium max-w-xs truncate" title={b.bookName}>
                        {b.bookName}
                      </td>
                      <td className="p-2.5 text-slate-400">{b.author}</td>
                      <td className="p-2.5">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 text-[11px]">
                          {b.category}
                        </span>
                      </td>
                      <td className="p-2.5 font-bold text-emerald-400">₹{b.price}</td>
                      <td className="p-2.5 text-slate-300">{b.stockQuantity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTable === 'ContactMessages' && (
            <div className="overflow-x-auto">
              {contactMessages.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <p>No messages recorded yet.</p>
                  <p className="text-[11px] mt-1">Submit a message via the Contact Us page to see it appear here in real time!</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider bg-slate-950/40">
                      <th className="p-2.5">ContactId (PK)</th>
                      <th className="p-2.5">Name</th>
                      <th className="p-2.5">Email</th>
                      <th className="p-2.5">Phone</th>
                      <th className="p-2.5">Message</th>
                      <th className="p-2.5">CreatedDate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {contactMessages.map((m) => (
                      <tr key={m.contactId} className="hover:bg-slate-800/40 text-slate-300">
                        <td className="p-2.5 text-cyan-400 font-bold">{m.contactId}</td>
                        <td className="p-2.5 text-white font-medium">{m.name}</td>
                        <td className="p-2.5 text-slate-400">{m.email}</td>
                        <td className="p-2.5 text-slate-400">{m.phone}</td>
                        <td className="p-2.5 text-slate-300 max-w-sm truncate" title={m.message}>
                          {m.message}
                        </td>
                        <td className="p-2.5 text-slate-500 text-[11px]">{m.createdDate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {activeTable === 'Orders' && (
            <div className="overflow-x-auto">
              {orders.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <p>No orders placed yet.</p>
                  <p className="text-[11px] mt-1">Add items to cart and complete checkout to generate real master-detail order records!</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider bg-slate-950/40">
                      <th className="p-2.5">OrderId (PK)</th>
                      <th className="p-2.5">OrderCode</th>
                      <th className="p-2.5">CustomerName</th>
                      <th className="p-2.5">Email</th>
                      <th className="p-2.5">TotalAmount</th>
                      <th className="p-2.5">Status</th>
                      <th className="p-2.5">OrderDate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {orders.map((o) => (
                      <tr key={o.orderId} className="hover:bg-slate-800/40 text-slate-300">
                        <td className="p-2.5 text-cyan-400 font-bold">{o.orderId}</td>
                        <td className="p-2.5 text-amber-400 font-bold">{o.orderCode}</td>
                        <td className="p-2.5 text-white font-medium">{o.customerName}</td>
                        <td className="p-2.5 text-slate-400">{o.email}</td>
                        <td className="p-2.5 font-bold text-emerald-400">₹{o.totalAmount}</td>
                        <td className="p-2.5">
                          <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] border border-emerald-800">
                            {o.status}
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-500 text-[11px]">{o.orderDate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {activeTable === 'OrderDetails' && (
            <div className="overflow-x-auto">
              {allOrderDetails.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <p>No order details line items yet.</p>
                  <p className="text-[11px] mt-1">Order details represent the child relationship linked via Foreign Key to Orders.OrderId.</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider bg-slate-950/40">
                      <th className="p-2.5">OrderDetailId (PK)</th>
                      <th className="p-2.5">OrderId (FK)</th>
                      <th className="p-2.5">BookId (FK)</th>
                      <th className="p-2.5">BookTitle</th>
                      <th className="p-2.5">Quantity</th>
                      <th className="p-2.5">Price</th>
                      <th className="p-2.5">LineTotal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {allOrderDetails.map((d, index) => (
                      <tr key={index} className="hover:bg-slate-800/40 text-slate-300">
                        <td className="p-2.5 text-cyan-400 font-bold">{d.orderDetailId}</td>
                        <td className="p-2.5 text-amber-400 font-bold">#{d.orderId}</td>
                        <td className="p-2.5 text-slate-400">{d.bookId}</td>
                        <td className="p-2.5 text-white font-medium">{d.bookName}</td>
                        <td className="p-2.5 text-slate-300">{d.quantity}</td>
                        <td className="p-2.5 text-slate-300">₹{d.price}</td>
                        <td className="p-2.5 font-bold text-emerald-400">₹{d.quantity * d.price}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </div>

        {/* Footer with SQL Connection Details */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>T-SQL Script file: <code className="text-cyan-300">Database/BookNestDB.sql</code></span>
          </div>
          <div className="text-[11px] text-slate-500">
            Entity Framework 6 Database Context: <code className="text-slate-400">BookNestDbContext</code>
          </div>
        </div>
      </div>
    </div>
  );
};
