import React, { useState } from 'react';
import { Github, Copy, Check, Terminal, FileText, CheckCircle2, ShieldCheck, GitBranch, ArrowRight } from 'lucide-react';

export const GitHubGuide: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const gitCommands = `# 1. Open Terminal or Git Bash in project folder:
cd BookNest

# 2. Initialize Git repository
git init

# 3. Add all files to staging
git add .

# 4. Make initial commit
git commit -m "feat: initial commit of BookNest ASP.NET MVC project with models, views, and database scripts"

# 5. Set main branch
git branch -M main

# 6. Add your GitHub repository as remote (replace with your repo URL)
git remote add origin https://github.com/your-username/BookNest-ASP.NET-MVC-Project.git

# 7. Push to GitHub
git push -u origin main`;

  const gitignoreContent = `## Visual Studio / ASP.NET (.NET Framework) .gitignore
.vs/
[Bb]in/
[Oo]bj/
packages/
*.user
*.suo
*.userosscache
*.sln.docstates
*.mdf
*.ldf
*.log
Thumbs.db
Desktop.ini
_UpgradeReport_Files/
Backup*/
UpgradeLog*.XML
UpgradeLog*.htm`;

  const readmeTemplate = `# BookNest – Online Book Store (ASP.NET MVC 5)

> **BCA Mini Project Submission**  
> **Student Name:** [Your Name]  
> **Roll No / University Seat No:** [Your Roll Number]  
> **Department:** Department of Computer Applications  
> **College:** [Your College Name]  
> **Project Guide:** [Guide's Name / Professor]  

---

## 📌 Project Overview
**BookNest** is a 3-tier web application developed using **ASP.NET .NET Framework MVC 5**, **C#**, and **Microsoft SQL Server LocalDB**. It provides an intuitive catalog for students to browse academic textbooks, check stock availability, manage shopping cart items in session state, and submit orders and inquiries.

## 🛠️ Technology Stack
- **Framework:** ASP.NET MVC 5 (.NET Framework 4.8)
- **Language:** C#
- **Database:** Microsoft SQL Server / SQL Server LocalDB
- **ORM:** Entity Framework 6 (Code-First / DbContext)
- **Frontend:** Razor View Engine (.cshtml), HTML5, CSS3, Bootstrap 5, JavaScript
- **IDE:** Microsoft Visual Studio 2019 / 2022

## 📂 Project Structure
\`\`\`
BookNest/
├── Controllers/
│   ├── HomeController.cs
│   ├── BooksController.cs
│   ├── CartController.cs
│   ├── ContactController.cs
│   └── OrderController.cs
├── Models/
│   ├── Book.cs
│   ├── Order.cs
│   ├── OrderDetail.cs
│   ├── ContactMessage.cs
│   ├── CartItem.cs
│   └── BookNestDbContext.cs
├── Views/
│   ├── Home/
│   ├── Books/
│   ├── Cart/
│   ├── Contact/
│   ├── Order/
│   └── Shared/_Layout.cshtml
├── Database/
│   └── BookNestDB.sql
├── Web.config
└── BookNest.sln
\`\`\`

## 🚀 How to Run Locally
1. Clone this repository:
   \`\`\`bash
   git clone https://github.com/your-username/BookNest-ASP.NET-MVC-Project.git
   \`\`\`
2. Open \`BookNest.sln\` in **Visual Studio 2019/2022**.
3. Open **SQL Server Object Explorer** and create database \`BookNestDB\`.
4. Execute \`Database/BookNestDB.sql\` to create tables and insert sample books.
5. In Visual Studio, restore NuGet packages (Entity Framework 6.4.4).
6. Press **F5** to run the application on IIS Express.

## 👥 Features
- [x] Responsive navigation bar and dynamic layout
- [x] Book catalog with category filtering and keyword search
- [x] Book details modal with quantity selector and stock checks
- [x] Session-based cart with dynamic subtotals and line totals
- [x] Simulated order placement with transaction persistence
- [x] Contact feedback form with Data Annotation validations
`;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <Github className="w-7 h-7 text-slate-900" />
          <span>Git & GitHub Setup Guide for BCA Students</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Complete instructions for version control, repository creation, .gitignore rules, and professional college README documentation.
        </p>
      </div>

      {/* 1. Terminal Commands */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-md p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>Git Initialization & Push Commands</span>
          </div>
          <button
            onClick={() => copyText(gitCommands, 'git')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition flex items-center gap-1.5 border border-slate-700"
          >
            {copiedSection === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'git' ? 'Copied Commands!' : 'Copy Commands'}</span>
          </button>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-amber-300 leading-relaxed overflow-x-auto">
          <pre>{gitCommands}</pre>
        </div>
      </div>

      {/* 2. Visual Studio .gitignore */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" />
              <span>Recommended .gitignore File</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Prevents large compiled binaries (<code>bin/</code>, <code>obj/</code>, <code>.vs/</code>) from cluttering your repository.
            </p>
          </div>
          <button
            onClick={() => copyText(gitignoreContent, 'gitignore')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition flex items-center gap-1.5 border border-slate-300"
          >
            {copiedSection === 'gitignore' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'gitignore' ? 'Copied .gitignore!' : 'Copy .gitignore'}</span>
          </button>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto">
          <pre>{gitignoreContent}</pre>
        </div>
      </div>

      {/* 3. Recommended Commit Strategy */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-3">
        <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-emerald-600" />
          <span>Professional BCA Commit History Recommendations</span>
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          College evaluators love seeing progressive commits rather than one single giant commit. Follow this recommended sequence:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono text-slate-700">
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>feat: scaffold ASP.NET MVC project structure</code>
          </div>
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>feat(db): add BookNestDB.sql schema and seed</code>
          </div>
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>feat(models): create Book and Order entities with EF</code>
          </div>
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>feat(views): design Bootstrap layout and catalog</code>
          </div>
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>feat(cart): implement session based shopping cart</code>
          </div>
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
            <code>docs: add college project submission README</code>
          </div>
        </div>
      </div>

      {/* 4. README.md Template */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-500" />
              <span>Submission-Ready README.md Template</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Copy and replace placeholder brackets with your student details.
            </p>
          </div>
          <button
            onClick={() => copyText(readmeTemplate, 'readme')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition flex items-center gap-1.5 border border-slate-300"
          >
            {copiedSection === 'readme' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'readme' ? 'Copied README!' : 'Copy README.md'}</span>
          </button>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto max-h-96">
          <pre>{readmeTemplate}</pre>
        </div>
      </div>
    </div>
  );
};
