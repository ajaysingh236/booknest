import React, { useState } from 'react';
import {
  Monitor,
  CheckCircle2,
  Copy,
  Check,
  Terminal,
  Database,
  Play,
  Package,
  Layers,
  FileCode,
  AlertTriangle,
} from 'lucide-react';

export const VisualStudioGuide: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      step: 1,
      title: 'Open Visual Studio & Create New Project',
      icon: <Monitor className="w-5 h-5 text-blue-500" />,
      content: (
        <div className="space-y-2 text-xs sm:text-sm text-slate-600">
          <p>
            1. Launch <strong>Visual Studio 2019</strong> or <strong>Visual Studio 2022</strong>.
          </p>
          <p>
            2. Click on <span className="font-semibold text-slate-800">"Create a new project"</span>.
          </p>
          <p>
            3. In the search box at the top, type <code>ASP.NET Web Application (.NET Framework)</code> with C#.
          </p>
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-xs">
            <strong>Critical Note for BCA Evaluation:</strong> Make sure you select{' '}
            <em>"ASP.NET Web Application (.NET Framework)"</em> and <strong>NOT</strong> ASP.NET Core! The framework dropdown at the bottom should show <code>.NET Framework 4.7.2</code> or <code>.NET Framework 4.8</code>.
          </div>
          <p>
            4. Set Project Name: <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-800">BookNest</code>
          </p>
          <p>
            5. Set Solution Name: <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-800">BookNest</code>
          </p>
        </div>
      ),
    },
    {
      step: 2,
      title: 'Select MVC Template & Authentication',
      icon: <Layers className="w-5 h-5 text-indigo-500" />,
      content: (
        <div className="space-y-2 text-xs sm:text-sm text-slate-600">
          <p>
            1. In the template selection dialog, click on <strong className="text-slate-800">MVC</strong>.
          </p>
          <p>
            2. Under Authentication on the right side, leave it as <span className="font-semibold text-slate-800">"No Authentication"</span> (or "Individual User Accounts" if desired). For a beginner college mini project, "No Authentication" is simplest.
          </p>
          <p>
            3. Ensure <span className="font-semibold text-slate-800">"Configure for HTTPS"</span> is checked.
          </p>
          <p>
            4. Click the <strong className="text-emerald-600">Create</strong> button. Visual Studio will scaffold the project structure with <code>Controllers</code>, <code>Models</code>, and <code>Views</code>.
          </p>
        </div>
      ),
    },
    {
      step: 3,
      title: 'Install Entity Framework 6 via NuGet Package Manager',
      icon: <Package className="w-5 h-5 text-amber-500" />,
      content: (
        <div className="space-y-3 text-xs sm:text-sm text-slate-600">
          <p>Entity Framework is required to talk to SQL Server using C# classes instead of raw ADO.NET.</p>
          <p>
            <strong>Option A (Package Manager Console):</strong>
            <br />
            Go to <em>Tools → NuGet Package Manager → Package Manager Console</em> and run:
          </p>
          <div className="relative p-3 bg-slate-900 text-amber-400 rounded-lg font-mono text-xs flex items-center justify-between">
            <code>Install-Package EntityFramework -Version 6.4.4</code>
            <button
              onClick={() => copyToClipboard('Install-Package EntityFramework -Version 6.4.4', 3)}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
            >
              {copiedIndex === 3 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <p>
            <strong>Option B (GUI):</strong> Right-click project in Solution Explorer → <em>Manage NuGet Packages</em> → Browse → Search <code>EntityFramework</code> → Click Install.
          </p>
        </div>
      ),
    },
    {
      step: 4,
      title: 'Setup SQL Server Database (BookNestDB.sql)',
      icon: <Database className="w-5 h-5 text-cyan-500" />,
      content: (
        <div className="space-y-3 text-xs sm:text-sm text-slate-600">
          <p>You can execute the SQL script either in SQL Server Management Studio (SSMS) or right inside Visual Studio:</p>
          <p>
            1. In Visual Studio, go to <em>View → SQL Server Object Explorer</em> (or <em>Server Explorer</em>).
          </p>
          <p>
            2. Expand <strong>SQL Server → (localdb)\MSSQLLocalDB</strong>.
          </p>
          <p>
            3. Right-click <strong>Databases</strong> → Click <span className="font-semibold text-slate-800">"Add New Database"</span> → Name it <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">BookNestDB</code>.
          </p>
          <p>
            4. Right-click on <code>BookNestDB</code> → Select <strong>"New Query..."</strong>.
          </p>
          <p>
            5. Copy the entire contents of <code>Database/BookNestDB.sql</code> from our Source Code tab, paste it into the query window, and click the green <strong>Execute (Ctrl + Shift + E)</strong> button.
          </p>
          <p className="text-emerald-700 font-semibold text-xs">
            ✓ This will create the Books, ContactMessages, Orders, and OrderDetails tables and populate 10 realistic books!
          </p>
        </div>
      ),
    },
    {
      step: 5,
      title: 'Configure Web.config Connection String',
      icon: <Terminal className="w-5 h-5 text-purple-500" />,
      content: (
        <div className="space-y-2 text-xs sm:text-sm text-slate-600">
          <p>
            Open <code>Web.config</code> located at the root of the project and ensure the <code>&lt;connectionStrings&gt;</code> block points to LocalDB:
          </p>
          <div className="relative p-3 bg-slate-900 text-cyan-300 rounded-lg font-mono text-xs flex items-center justify-between overflow-x-auto">
            <pre>
              {`<connectionStrings>
  <add name="BookNestDbContext" 
       connectionString="Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=BookNestDB;Integrated Security=True;MultipleActiveResultSets=True" 
       providerName="System.Data.SqlClient" />
</connectionStrings>`}
            </pre>
            <button
              onClick={() =>
                copyToClipboard(
                  '<connectionStrings>\n  <add name="BookNestDbContext" connectionString="Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=BookNestDB;Integrated Security=True;MultipleActiveResultSets=True" providerName="System.Data.SqlClient" />\n</connectionStrings>',
                  5
                )
              }
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 ml-2 flex-shrink-0"
            >
              {copiedIndex === 5 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      ),
    },
    {
      step: 6,
      title: 'Add Models, Controllers, and Views',
      icon: <FileCode className="w-5 h-5 text-emerald-500" />,
      content: (
        <div className="space-y-2 text-xs sm:text-sm text-slate-600">
          <p>
            1. <strong>Models:</strong> Right-click <code>Models</code> folder → Add → Class → Add <code>Book.cs</code>, <code>ContactMessage.cs</code>, <code>Order.cs</code>, <code>OrderDetail.cs</code>, <code>CartItem.cs</code>, and <code>BookNestDbContext.cs</code>.
          </p>
          <p>
            2. <strong>Controllers:</strong> Right-click <code>Controllers</code> folder → Add → Controller → Create <code>HomeController.cs</code>, <code>BooksController.cs</code>, <code>CartController.cs</code>, <code>ContactController.cs</code>, and <code>OrderController.cs</code>.
          </p>
          <p>
            3. <strong>Views:</strong> Inside <code>Views/Shared/_Layout.cshtml</code>, paste the layout file with navigation bar and footer. Create subfolders for <code>Books</code>, <code>Cart</code>, <code>Contact</code>, and <code>Order</code> with their corresponding <code>.cshtml</code> files.
          </p>
          <p className="text-xs text-slate-500 italic">
            Tip: You can use our "Download Solution (.ZIP)" button to get the entire project pre-organized!
          </p>
        </div>
      ),
    },
    {
      step: 7,
      title: 'Build & Run the Project (IIS Express F5)',
      icon: <Play className="w-5 h-5 text-rose-500" />,
      content: (
        <div className="space-y-2 text-xs sm:text-sm text-slate-600">
          <p>
            1. Press <kbd className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 font-mono text-xs">Ctrl + Shift + B</kbd> to build the solution. Ensure the output window says <code>Build: 1 succeeded, 0 failed</code>.
          </p>
          <p>
            2. Press <kbd className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 font-mono text-xs">F5</kbd> (or click the green "IIS Express (Google Chrome)" button in the top toolbar).
          </p>
          <p>
            3. Your browser will launch at <code>http://localhost:port/</code> and render the BookNest homepage.
          </p>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <Monitor className="w-7 h-7 text-indigo-600" />
          <span>Visual Studio & SQL Server LocalDB Setup Guide</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Detailed step-by-step walkthrough tailored for BCA students and beginners. Follow each numbered step to execute BookNest smoothly on your Windows machine.
        </p>
      </div>

      <div className="space-y-4">
        {steps.map((item) => (
          <div key={item.step} className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                {item.icon}
              </div>
              <h3 className="font-bold text-slate-900 text-base">
                Step {item.step}: {item.title}
              </h3>
            </div>
            <div className="pl-11">{item.content}</div>
          </div>
        ))}
      </div>

      {/* Troubleshooting Tips */}
      <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-6 space-y-3">
        <h4 className="font-bold text-amber-900 text-sm flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600" />
          <span>Common Beginner Mistakes & How to Fix Them</span>
        </h4>
        <ul className="text-xs text-amber-900/90 space-y-2 list-disc list-inside">
          <li>
            <strong>"Cannot attach the file ... to database":</strong> Open SQL Server Object Explorer and ensure <code>(localdb)\MSSQLLocalDB</code> is running. Right-click and choose "Start".
          </li>
          <li>
            <strong>"The Model backing the DbContext has changed":</strong> Re-run the <code>Database/BookNestDB.sql</code> script or update your model properties to match the SQL column names exactly.
          </li>
          <li>
            <strong>Session is null:</strong> Ensure <code>&lt;sessionState mode="InProc" /&gt;</code> is present in <code>Web.config</code> inside <code>&lt;system.web&gt;</code>.
          </li>
          <li>
            <strong>Images not showing:</strong> All sample images in BookNest use HTTPS Unsplash URLs; ensure your machine is connected to the internet during first run.
          </li>
        </ul>
      </div>
    </div>
  );
};
