import React, { useState, useMemo } from 'react';
import { VIVA_QUESTIONS } from '../../data/vivaQuestions';
import { VivaQuestion } from '../../types';
import { GraduationCap, Search, HelpCircle, ChevronDown, ChevronUp, Sparkles, Filter, CheckCircle2 } from 'lucide-react';

export const VivaPreparation: React.FC = () => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedIds, setExpandedIds] = useState<number[]>([1, 2]); // First two opened by default

  const categories = ['All', 'MVC Architecture', 'C# & Entity Framework', 'State & Routing', 'Database & Web.config'];

  const filteredQuestions = useMemo(() => {
    return VIVA_QUESTIONS.filter((q) => {
      const matchesCat = selectedCategory === 'All' || q.category === selectedCategory;
      const matchesSearch =
        q.question.toLowerCase().includes(search.toLowerCase()) ||
        q.answer.toLowerCase().includes(search.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [search, selectedCategory]);

  const toggleExpand = (id: number) => {
    setExpandedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const expandAll = () => {
    setExpandedIds(VIVA_QUESTIONS.map((q) => q.id));
  };

  const collapseAll = () => {
    setExpandedIds([]);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 sm:p-8 rounded-2xl border border-slate-700/60 shadow-lg text-white">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-400/20 text-amber-300 border border-amber-400/30 mb-2">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>External Examiner Q&A Guide</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          BCA Mini Project Viva Voce Preparation
        </h2>
        <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
          20 curated, student-friendly questions and answers covering ASP.NET MVC 5, Entity Framework 6, Session state, SQL Server LocalDB, and C# OOP concepts.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Categories */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" />
            Topic:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                selectedCategory === cat
                  ? 'bg-indigo-950 text-indigo-200 shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search viva questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-amber-400"
          />
        </div>
      </div>

      {/* Expand/Collapse Controls */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <span>Showing {filteredQuestions.length} of {VIVA_QUESTIONS.length} Viva Questions</span>
        <div className="flex items-center gap-3">
          <button onClick={expandAll} className="hover:text-indigo-600 font-medium">Expand All</button>
          <span>•</span>
          <button onClick={collapseAll} className="hover:text-indigo-600 font-medium">Collapse All</button>
        </div>
      </div>

      {/* Questions Accordion */}
      <div className="space-y-3">
        {filteredQuestions.map((q) => {
          const isExpanded = expandedIds.includes(q.id);
          return (
            <div
              key={q.id}
              className="bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden transition"
            >
              <button
                onClick={() => toggleExpand(q.id)}
                className="w-full p-4 sm:p-5 text-left flex items-start justify-between gap-4 hover:bg-slate-50/50 transition"
              >
                <div className="flex items-start gap-3 flex-1">
                  <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {q.id}
                  </span>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full inline-block mb-1">
                      {q.category}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                      {q.question}
                    </h3>
                  </div>
                </div>

                <div className="text-slate-400 p-1">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {isExpanded && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-700 border-t border-slate-100 bg-slate-50/40 space-y-2">
                  <div className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-2xs leading-relaxed whitespace-pre-line text-slate-800">
                    {q.answer}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
