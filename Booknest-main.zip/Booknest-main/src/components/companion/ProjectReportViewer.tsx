import React, { useState } from 'react';
import { PROJECT_REPORT_SECTIONS } from '../../data/projectReport';
import { ReportSection } from '../../types';
import { FileText, Copy, Check, Printer, Bookmark, ChevronRight, BookOpen } from 'lucide-react';

export const ProjectReportViewer: React.FC = () => {
  const [activeSectionNum, setActiveSectionNum] = useState<number>(1);
  const [copied, setCopied] = useState(false);
  const [copiedFull, setCopiedFull] = useState(false);

  const activeSection =
    PROJECT_REPORT_SECTIONS.find((s) => s.number === activeSectionNum) || PROJECT_REPORT_SECTIONS[0];

  const handleCopySection = () => {
    navigator.clipboard.writeText(`${activeSection.title}\n\n${activeSection.content}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyFullReport = () => {
    const fullText = PROJECT_REPORT_SECTIONS.map((s) => `### Section ${s.number}: ${s.title}\n\n${s.content}\n\n---\n`).join('\n');
    navigator.clipboard.writeText(fullText);
    setCopiedFull(true);
    setTimeout(() => setCopiedFull(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 rounded-2xl border border-slate-700/60 shadow-lg text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-400/20 text-indigo-300 border border-indigo-400/30 mb-2">
            <Bookmark className="w-3.5 h-3.5" />
            <span>Academic Mini-Project Documentation</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">College Project Report (20 Standard Sections)</h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Complete academic project report ready for college documentation, spiral binding, and external viva evaluation.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleCopyFullReport}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition flex items-center gap-2 border border-slate-700"
          >
            {copiedFull ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copiedFull ? 'Copied Full Report!' : 'Copy All 20 Sections'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition flex items-center gap-2 shadow-md shadow-amber-400/20"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar + Report View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Table of Contents Sidebar */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col max-h-[750px]">
          <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
              <span>Table of Contents</span>
            </span>
            <span className="text-xs text-slate-400 font-mono">20 Sections</span>
          </div>

          <div className="p-2 overflow-y-auto space-y-1 flex-1 text-xs">
            {PROJECT_REPORT_SECTIONS.map((section) => {
              const isSelected = activeSectionNum === section.number;
              return (
                <button
                  key={section.number}
                  onClick={() => setActiveSectionNum(section.number)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition ${
                    isSelected
                      ? 'bg-indigo-50 text-indigo-900 font-bold border border-indigo-200'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold flex items-center justify-center flex-shrink-0">
                      {section.number}
                    </span>
                    <span className="truncate">{section.title}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-indigo-600' : 'text-slate-300'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Section Reading View */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col min-h-[500px]">
          {/* Section Header */}
          <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-indigo-600 uppercase font-bold tracking-wider">
                Section {activeSection.number} of 20
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">{activeSection.title}</h3>
            </div>

            <button
              onClick={handleCopySection}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Section!' : 'Copy Section'}</span>
            </button>
          </div>

          {/* Section Content */}
          <div className="p-6 sm:p-8 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed font-sans">
            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200/80 whitespace-pre-wrap font-mono text-xs sm:text-[13px] text-slate-800 leading-relaxed">
              {activeSection.content}
            </div>
          </div>

          {/* Navigation Between Sections */}
          <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs">
            {(() => {
              const prev = PROJECT_REPORT_SECTIONS.find((s) => s.number === activeSection.number - 1);
              const next = PROJECT_REPORT_SECTIONS.find((s) => s.number === activeSection.number + 1);

              return (
                <>
                  <div>
                    {prev ? (
                      <button
                        onClick={() => setActiveSectionNum(prev.number)}
                        className="font-medium text-slate-600 hover:text-indigo-600"
                      >
                        ← Previous: {prev.title}
                      </button>
                    ) : (
                      <span className="text-slate-300">Start of Report</span>
                    )}
                  </div>
                  <div>
                    {next ? (
                      <button
                        onClick={() => setActiveSectionNum(next.number)}
                        className="font-bold text-indigo-600 hover:text-indigo-800"
                      >
                        Next: {next.title} →
                      </button>
                    ) : (
                      <span className="text-slate-300">End of Report</span>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      </div>
    </div>
  );
};
