import React, { useState } from 'react';
import { DOTNET_PROJECT_FILES } from '../../data/dotNetProjectFiles';
import { DotNetSourceFile } from '../../types';
import { generateAndDownloadProjectZip } from '../../services/zipExporter';
import {
  FileCode,
  Folder,
  FolderOpen,
  Download,
  Copy,
  Check,
  Search,
  Code2,
  Database,
  FileText,
  Settings,
  Layers,
  Sparkles,
} from 'lucide-react';

export const SourceCodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<DotNetSourceFile>(DOTNET_PROJECT_FILES[4]); // Defaults to Models/Book.cs
  const [searchFilter, setSearchFilter] = useState('');
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const filteredFiles = DOTNET_PROJECT_FILES.filter(
    (f) =>
      f.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      f.category.toLowerCase().includes(searchFilter.toLowerCase()) ||
      f.path.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      await generateAndDownloadProjectZip();
    } catch (err) {
      console.error('ZIP generation failed:', err);
      alert('Failed to generate ZIP. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Model':
        return <Layers className="w-4 h-4 text-blue-400" />;
      case 'Controller':
        return <Code2 className="w-4 h-4 text-emerald-400" />;
      case 'View':
        return <FileCode className="w-4 h-4 text-amber-400" />;
      case 'Database':
        return <Database className="w-4 h-4 text-cyan-400" />;
      case 'Config':
        return <Settings className="w-4 h-4 text-purple-400" />;
      default:
        return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 rounded-2xl border border-slate-700/60 shadow-lg text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Complete ASP.NET .NET Framework Solution</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">C# & Razor Source Code Explorer</h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Browse, inspect, and copy complete production-ready source code for Models, Controllers, Razor Views, Web.config, and SQL scripts.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={downloading}
          className="px-5 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 flex-shrink-0 disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>{downloading ? 'Building ZIP...' : 'Download Solution (.ZIP)'}</span>
        </button>
      </div>

      {/* Main Studio View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Solution Explorer Sidebar */}
        <div className="lg:col-span-4 bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-md flex flex-col max-h-[750px]">
          {/* Sidebar Top Search */}
          <div className="p-3.5 border-b border-slate-800 bg-slate-950">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Solution Explorer</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">BookNest.sln</span>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter files (e.g. Controller, Model)..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-400"
              />
            </div>
          </div>

          {/* File Tree List */}
          <div className="p-2 overflow-y-auto space-y-1 flex-1 font-mono text-xs">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg flex items-center gap-2.5 transition ${
                    isSelected
                      ? 'bg-amber-400/10 text-amber-300 border border-amber-400/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  {getCategoryIcon(file.category)}
                  <div className="truncate flex-1">
                    <span className="font-semibold block truncate text-slate-200">{file.name}</span>
                    <span className="text-[10px] text-slate-500 truncate block">{file.path}</span>
                  </div>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-sans uppercase font-bold ${
                      file.category === 'Model'
                        ? 'bg-blue-950 text-blue-400'
                        : file.category === 'Controller'
                        ? 'bg-emerald-950 text-emerald-400'
                        : file.category === 'View'
                        ? 'bg-amber-950 text-amber-400'
                        : file.category === 'Database'
                        ? 'bg-cyan-950 text-cyan-400'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Sidebar Footer Info */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
            <span>{DOTNET_PROJECT_FILES.length} Files Total</span>
            <span className="text-amber-400 font-semibold">.NET Framework 4.8</span>
          </div>
        </div>

        {/* Code Content Viewer */}
        <div className="lg:col-span-8 bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-md flex flex-col max-h-[750px]">
          {/* File Title Bar */}
          <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              {getCategoryIcon(selectedFile.category)}
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-mono text-sm font-bold text-white">{selectedFile.name}</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-sans">
                    {selectedFile.language}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{selectedFile.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition flex items-center gap-1.5 border border-slate-700"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied Code!' : 'Copy File'}</span>
              </button>
            </div>
          </div>

          {/* Code Text Area */}
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 font-mono text-xs sm:text-[13px] leading-relaxed bg-slate-950 text-slate-200 selection:bg-amber-400/30">
            <pre className="overflow-x-auto whitespace-pre">
              <code>{selectedFile.content}</code>
            </pre>
          </div>

          {/* Code Footer */}
          <div className="px-5 py-2.5 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Path: <code className="text-cyan-400 font-mono">{selectedFile.path}</code></span>
            <span>Lines: {selectedFile.content.split('\n').length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
