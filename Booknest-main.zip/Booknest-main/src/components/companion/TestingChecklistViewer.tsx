import React, { useState } from 'react';
import { TESTING_CHECKLIST } from '../../data/testingChecklist';
import { TestCase } from '../../types';
import { CheckSquare, CheckCircle2, XCircle, Clock, Copy, Check, Filter } from 'lucide-react';

export const TestingChecklistViewer: React.FC = () => {
  const [testCases, setTestCases] = useState<TestCase[]>(TESTING_CHECKLIST);
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [copied, setCopied] = useState(false);

  const toggleStatus = (id: number) => {
    setTestCases((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const nextStatus = t.status === 'Pass' ? 'Fail' : t.status === 'Fail' ? 'Pending' : 'Pass';
        return { ...t, status: nextStatus };
      })
    );
  };

  const filteredTests = testCases.filter((t) => {
    if (filterStatus === 'All') return true;
    return t.status === filterStatus;
  });

  const passCount = testCases.filter((t) => t.status === 'Pass').length;

  const handleCopyTestTable = () => {
    const markdown = [
      '| Test ID | Module | Test Description | Expected Result | Status | Remarks |',
      '|---|---|---|---|---|---|',
      ...testCases.map(
        (t) => `| TC-${t.id.toString().padStart(2, '0')} | ${t.module} | ${t.testCase} | ${t.expectedResult} | ${t.status} | ${t.remarks || 'Verified'} |`
      ),
    ].join('\n');

    navigator.clipboard.writeText(markdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 sm:p-8 rounded-2xl border border-slate-700/60 shadow-lg text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 mb-2">
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Academic Software Quality Assurance</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Manual Testing & Verification Checklist
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
            10 standard college test cases covering navigation, input validations, session cart operations, checkout transactions, and SQL persistence.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-800/80 border border-slate-700 px-4 py-2 rounded-xl text-center">
            <span className="text-xs text-slate-400 block">Pass Rate</span>
            <span className="text-xl font-extrabold text-emerald-400">
              {passCount} / {testCases.length} ({Math.round((passCount / testCases.length) * 100)}%)
            </span>
          </div>

          <button
            onClick={handleCopyTestTable}
            className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs transition flex items-center gap-2 shadow-md shadow-amber-400/20"
          >
            {copied ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Table!' : 'Copy Markdown'}</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-3 rounded-xl border border-slate-200/90 shadow-sm flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-400 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            Filter by Result:
          </span>
          {['All', 'Pass', 'Fail', 'Pending'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1 rounded-full font-medium transition ${
                filterStatus === st
                  ? 'bg-slate-900 text-amber-400'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <span className="text-slate-400 text-[11px]">
          Click any result badge to toggle status during viva testing
        </span>
      </div>

      {/* Test Cases Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold text-[11px] uppercase tracking-wider">
                <th className="p-3.5 sm:p-4">Test ID</th>
                <th className="p-3.5 sm:p-4">Module</th>
                <th className="p-3.5 sm:p-4">Test Description</th>
                <th className="p-3.5 sm:p-4">Expected Result</th>
                <th className="p-3.5 sm:p-4 text-center">Status</th>
                <th className="p-3.5 sm:p-4">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTests.map((tc) => (
                <tr key={tc.id} className="hover:bg-slate-50/50 transition">
                  <td className="p-3.5 sm:p-4 font-mono font-bold text-indigo-600 align-top">
                    TC-{tc.id.toString().padStart(2, '0')}
                  </td>
                  <td className="p-3.5 sm:p-4 font-semibold text-slate-700 align-top">
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {tc.module}
                    </span>
                  </td>
                  <td className="p-3.5 sm:p-4 font-medium text-slate-900 align-top">
                    {tc.testCase}
                  </td>
                  <td className="p-3.5 sm:p-4 text-slate-600 align-top leading-relaxed">
                    {tc.expectedResult}
                  </td>
                  <td className="p-3.5 sm:p-4 text-center align-top">
                    <button
                      onClick={() => toggleStatus(tc.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition shadow-xs ${
                        tc.status === 'Pass'
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : tc.status === 'Fail'
                          ? 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                          : 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                      }`}
                      title="Click to toggle status"
                    >
                      {tc.status === 'Pass' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                      {tc.status === 'Fail' && <XCircle className="w-3.5 h-3.5 text-rose-600" />}
                      {tc.status === 'Pending' && <Clock className="w-3.5 h-3.5 text-amber-600" />}
                      <span>{tc.status}</span>
                    </button>
                  </td>
                  <td className="p-3.5 sm:p-4 text-slate-500 text-xs align-top">
                    {tc.remarks || 'Verified'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
