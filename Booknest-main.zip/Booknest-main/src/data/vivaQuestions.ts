import { VivaQuestion } from '../types';

export const VIVA_QUESTIONS: VivaQuestion[] = [
  {
    id: 1,
    question: 'What is ASP.NET?',
    category: 'Core ASP.NET',
    answer: 'ASP.NET is an open-source, server-side web application framework developed by Microsoft to build dynamic web pages, interactive websites, and web services using .NET languages like C#.',
    keyPoints: ['Server-side web development framework', 'Developed by Microsoft', 'Supports C# and VB.NET', 'Generates HTML sent to the browser']
  },
  {
    id: 2,
    question: 'What is .NET Framework?',
    category: 'Core ASP.NET',
    answer: '.NET Framework is a software development platform developed by Microsoft that provides a managed execution environment called the Common Language Runtime (CLR) and a massive Class Library (FCL) to run Windows and web applications.',
    keyPoints: ['CLR (Common Language Runtime) handles memory and execution', 'FCL (Framework Class Library) provides prebuilt classes', 'Supports language interoperability', 'Traditional platform for Windows-based ASP.NET']
  },
  {
    id: 3,
    question: 'What is MVC architecture?',
    category: 'MVC Architecture',
    answer: 'MVC stands for Model-View-Controller. It is an architectural design pattern that separates an application into three interconnected components: data logic (Model), user interface (View), and input controller (Controller).',
    keyPoints: ['Separation of Concerns (SoC)', 'Improves testability and code maintainability', 'Model = Data, View = UI, Controller = Logic', 'No ViewState overhead unlike Web Forms']
  },
  {
    id: 4,
    question: 'What is a Model in ASP.NET MVC?',
    category: 'MVC Architecture',
    answer: 'A Model represents the business data and business logic of the application. In BookNest, models like Book.cs and Order.cs represent database tables, along with validation rules defined using Data Annotations.',
    keyPoints: ['Represents domain data and business rules', 'Maps to SQL database tables', 'Uses Data Annotations for validation like [Required], [Range]']
  },
  {
    id: 5,
    question: 'What is a View in ASP.NET MVC?',
    category: 'MVC Architecture',
    answer: 'A View is the user interface layer that presents data from the Model to the end user. In ASP.NET MVC, views use the Razor syntax (.cshtml files) to blend HTML with C# code.',
    keyPoints: ['Contains HTML, CSS, and Razor syntax (@)', 'Receives data from Controller via Model or ViewBag', 'Has no direct database access']
  },
  {
    id: 6,
    question: 'What is a Controller in ASP.NET MVC?',
    category: 'MVC Architecture',
    answer: 'A Controller acts as an intermediary coordinator. It handles incoming HTTP requests from the browser, interacts with the Model/database, and returns the appropriate View or JSON response.',
    keyPoints: ['Inherits from System.Web.Mvc.Controller', 'Contains Action methods (like Index(), Details())', 'Coordinates data flow between Model and View']
  },
  {
    id: 7,
    question: 'What is Entity Framework (EF)?',
    category: 'Database & EF',
    answer: 'Entity Framework is an Object-Relational Mapper (ORM) from Microsoft. It enables developers to work with relational databases like SQL Server using C# domain objects, eliminating the need to write raw ADO.NET SQL queries manually.',
    keyPoints: ['Object-Relational Mapping (ORM)', 'Uses LINQ to query database objects', 'Supports Code-First and Database-First approaches', 'Handles transactions, connections, and mapping']
  },
  {
    id: 8,
    question: 'What is SQL Server / LocalDB?',
    category: 'Database & EF',
    answer: 'Microsoft SQL Server is an enterprise Relational Database Management System (RDBMS). SQL Server LocalDB is a lightweight version of SQL Server Express designed for developers to run in-process without requiring a heavy background service.',
    keyPoints: ['RDBMS using Transact-SQL (T-SQL)', 'LocalDB runs as an on-demand developer instance', 'Connects via (LocalDb)\\MSSQLLocalDB', 'Stores data in .mdf database files']
  },
  {
    id: 9,
    question: 'What does CRUD stand for?',
    category: 'Database & EF',
    answer: 'CRUD stands for Create, Read, Update, and Delete. These are the four primary database operations required in persistent applications. In BookNest: Create (placing order, adding message), Read (listing books), Update (cart quantities), Delete (removing cart items).',
    keyPoints: ['Create = INSERT', 'Read = SELECT', 'Update = UPDATE', 'Delete = DELETE']
  },
  {
    id: 10,
    question: 'What is Razor View Engine?',
    category: 'MVC Architecture',
    answer: 'Razor is an ASP.NET view engine introduced in MVC 3. It provides a clean, concise syntax that allows embedding server-side C# code directly into HTML markup using the "@" symbol.',
    keyPoints: ['Files have .cshtml extension', 'Uses @ to transition between HTML and C#', 'Automatic HTML encoding to prevent XSS attacks', 'Clean and readable syntax']
  },
  {
    id: 11,
    question: 'What is URL Routing in ASP.NET MVC?',
    category: 'Core ASP.NET',
    answer: 'Routing is the URL pattern-matching mechanism in ASP.NET that maps incoming browser URLs to specific Controller action methods. The default route configured in RouteConfig.cs is "{controller}/{action}/{id}".',
    keyPoints: ['Configured in App_Start/RouteConfig.cs', 'Maps clean URLs to controller actions', 'Eliminates physical file paths like .aspx from URLs']
  },
  {
    id: 12,
    question: 'What is Session state in ASP.NET?',
    category: 'Session & State',
    answer: 'Session is a server-side state management feature used to store user-specific data across multiple HTTP requests during a user\'s visit. Each visitor receives a unique Session ID stored in a cookie. In BookNest, Session["Cart"] stores the user\'s shopping cart.',
    keyPoints: ['Stores user-specific state on the server', 'Identified by an ASP.NET_SessionId cookie', 'Default timeout is 20-30 minutes', 'Used for shopping carts, user login status']
  },
  {
    id: 13,
    question: 'Why is Bootstrap used in this project?',
    category: 'Core ASP.NET',
    answer: 'Bootstrap is an open-source front-end CSS framework. It provides a mobile-first responsive grid system, prebuilt UI components (cards, navbar, modals, buttons), and ensures cross-browser consistency without writing extensive custom CSS.',
    keyPoints: ['12-column responsive grid system', 'Prebuilt components like navbar, cards, alerts', 'Ensures mobile and tablet compatibility', 'Speeds up frontend development']
  },
  {
    id: 14,
    question: 'How does the shopping cart work in BookNest?',
    category: 'Session & State',
    answer: 'When a user clicks "Add to Cart", the CartController checks if Session["Cart"] exists. If not, it creates a new List<CartItem>. If the book already exists, it increments the quantity; otherwise, it appends a new CartItem. The grand total is calculated by summing Subtotal values.',
    keyPoints: ['Cart stored in Session["Cart"] as List<CartItem>', 'In-memory state per active user session', 'Does not clutter database until final checkout', 'Calculates subtotal and grand total dynamically']
  },
  {
    id: 15,
    question: 'How is the database connected in ASP.NET MVC?',
    category: 'Database & EF',
    answer: 'The database connection is defined in the <connectionStrings> tag of Web.config using the SQL Server LocalDB connection string. The BookNestDbContext class inherits from EF DbContext and passes this connection name to its base constructor.',
    keyPoints: ['Connection string configured in Web.config', 'DbContext connects to (LocalDb)\\MSSQLLocalDB', 'System.Data.SqlClient ADO.NET provider is used', 'EF handles opening and closing SQL connections automatically']
  },
  {
    id: 16,
    question: 'What is Git?',
    category: 'Git & Version Control',
    answer: 'Git is a distributed version control system (VCS) that tracks changes in source code files over time. It allows developers to revert to previous versions, create branches for new features, and collaborate efficiently.',
    keyPoints: ['Distributed version control system created by Linus Torvalds', 'Tracks file history with cryptographic SHA-1 hashes', 'Works completely offline locally', 'Enables non-linear branching and merging']
  },
  {
    id: 17,
    question: 'What is the difference between Git and GitHub?',
    category: 'Git & Version Control',
    answer: 'Git is a local command-line software tool that manages version control on your machine. GitHub is a cloud-based hosting service and web platform that hosts Git repositories online, enabling remote backup, project submission, and team collaboration.',
    keyPoints: ['Git is a tool installed on your computer', 'GitHub is a cloud platform/website that stores Git repos', 'Git works offline; GitHub requires internet', 'GitHub provides pull requests, issues, and release hosting']
  },
  {
    id: 18,
    question: 'How does GitHub help in this mini project?',
    category: 'Git & Version Control',
    answer: 'GitHub provides a secure remote backup of our project source code, showcases our code to professors and recruiters, maintains a clear commit history demonstrating project progression, and allows easy sharing of the repository URL for evaluation.',
    keyPoints: ['Remote cloud backup preventing data loss', 'Professional code portfolio for viva/interviews', 'Commit history proves authenticity of student work', 'Simple submission via repository link']
  },
  {
    id: 19,
    question: 'What technical challenges did you face and resolve?',
    category: 'Viva Tips',
    answer: 'Key challenges included configuring the SQL Server LocalDB connection string in Web.config, handling Entity Framework database migrations, ensuring session-based cart data stayed consistent on page reloads, and applying Bootstrap cards responsively on mobile displays.',
    keyPoints: ['LocalDB connection string troubleshooting', 'Model state validation with Data Annotations', 'Session persistence for cart items', 'Master-detail table relationships in EF (Orders & OrderDetails)']
  },
  {
    id: 20,
    question: 'What future improvements can be made to BookNest?',
    category: 'Viva Tips',
    answer: 'Future enhancements include integrating real payment gateways (such as Razorpay or Stripe), adding user registration/login using ASP.NET Identity, implementing an Admin dashboard to manage inventory and view sales graphs, and enabling customer reviews/ratings.',
    keyPoints: ['Payment gateway integration (Razorpay/Stripe)', 'ASP.NET Identity for User / Admin login roles', 'Admin CMS dashboard for inventory management', 'Email/SMS order confirmation notifications']
  }
];
