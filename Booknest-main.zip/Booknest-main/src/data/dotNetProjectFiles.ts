import { DotNetSourceFile } from '../types';

export const DOTNET_PROJECT_FILES: DotNetSourceFile[] = [
  // 1. Solution File
  {
    path: 'BookNest.sln',
    name: 'BookNest.sln',
    category: 'Solution',
    language: 'text',
    description: 'Visual Studio Solution file that groups project files and configurations.',
    content: `Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.8.34330.188
MinimumVisualStudioVersion = 10.0.40219.1
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "BookNest", "BookNest\\BookNest.csproj", "{A87B2E40-1A22-4D93-9F94-52E2A68181A0}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Any CPU = Debug|Any CPU
		Release|Any CPU = Release|Any CPU
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{A87B2E40-1A22-4D93-9F94-52E2A68181A0}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{A87B2E40-1A22-4D93-9F94-52E2A68181A0}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{A87B2E40-1A22-4D93-9F94-52E2A68181A0}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{A87B2E40-1A22-4D93-9F94-52E2A68181A0}.Release|Any CPU.Build.0 = Release|Any CPU
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
EndGlobal`
  },

  // 2. packages.config
  {
    path: 'packages.config',
    name: 'packages.config',
    category: 'Config',
    language: 'xml',
    description: 'NuGet packages definition including Entity Framework 6 and ASP.NET MVC 5.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<packages>
  <package id="EntityFramework" version="6.4.4" targetFramework="net48" />
  <package id="Microsoft.AspNet.Mvc" version="5.2.9" targetFramework="net48" />
  <package id="Microsoft.AspNet.Razor" version="3.2.9" targetFramework="net48" />
  <package id="Microsoft.AspNet.WebPages" version="3.2.9" targetFramework="net48" />
  <package id="Microsoft.Web.Infrastructure" version="1.0.0.0" targetFramework="net48" />
</packages>`
  },

  // 3. Web.config
  {
    path: 'Web.config',
    name: 'Web.config',
    category: 'Config',
    language: 'xml',
    description: 'Application configuration including LocalDB connection string and Entity Framework provider.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<!--
  For more information on how to configure your ASP.NET application, please visit
  https://go.microsoft.com/fwlink/?LinkId=301880
  -->
<configuration>
  <configSections>
    <section name="entityFramework" type="System.Data.Entity.Internal.ConfigFile.EntityFrameworkSection, EntityFramework, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" requirePermission="false" />
  </configSections>

  <connectionStrings>
    <!-- SQL Server LocalDB connection string for BookNestDB -->
    <add name="BookNestDbContext" 
         connectionString="Data Source=(LocalDb)\\MSSQLLocalDB;Initial Catalog=BookNestDB;Integrated Security=True;MultipleActiveResultSets=True" 
         providerName="System.Data.SqlClient" />
  </connectionStrings>

  <appSettings>
    <add key="webpages:Version" value="3.0.0.0" />
    <add key="webpages:Enabled" value="false" />
    <add key="ClientValidationEnabled" value="true" />
    <add key="UnobtrusiveJavaScriptEnabled" value="true" />
  </appSettings>

  <system.web>
    <compilation debug="true" targetFramework="4.8" />
    <httpRuntime targetFramework="4.8" />
    <sessionState mode="InProc" timeout="30" />
  </system.web>

  <system.webServer>
    <validation validateIntegratedModeConfiguration="false" />
    <modules runAllManagedModulesForAllRequests="true">
      <remove name="UrlRoutingModule-4.0" />
      <add name="UrlRoutingModule-4.0" type="System.Web.Routing.UrlRoutingModule" preCondition="" />
    </modules>
    <handlers>
      <remove name="ExtensionlessUrlHandler-Integrated-4.0" />
      <remove name="OPTIONSVerbHandler" />
      <remove name="TRACEVerbHandler" />
      <add name="ExtensionlessUrlHandler-Integrated-4.0" path="*." verb="*" type="System.Web.Handlers.TransferRequestHandler" preCondition="integratedMode,runtimeVersionv4.0" />
    </handlers>
  </system.webServer>

  <runtime>
    <assemblyBinding xmlns="urn:schemas-microsoft-com:asm.v1">
      <dependentAssembly>
        <assemblyIdentity name="System.Web.Helpers" publicKeyToken="31bf3856ad364e35" />
        <bindingRedirect oldVersion="1.0.0.0-3.0.0.0" newVersion="3.0.0.0" />
      </dependentAssembly>
      <dependentAssembly>
        <assemblyIdentity name="System.Web.WebPages" publicKeyToken="31bf3856ad364e35" />
        <bindingRedirect oldVersion="1.0.0.0-3.0.0.0" newVersion="3.0.0.0" />
      </dependentAssembly>
      <dependentAssembly>
        <assemblyIdentity name="System.Web.Mvc" publicKeyToken="31bf3856ad364e35" />
        <bindingRedirect oldVersion="1.0.0.0-5.2.9.0" newVersion="5.2.9.0" />
      </dependentAssembly>
    </assemblyBinding>
  </runtime>

  <entityFramework>
    <defaultConnectionFactory type="System.Data.Entity.Infrastructure.LocalDbConnectionFactory, EntityFramework">
      <parameters>
        <parameter value="mssqllocaldb" />
      </parameters>
    </defaultConnectionFactory>
    <providers>
      <provider invariantName="System.Data.SqlClient" type="System.Data.Entity.SqlServer.SqlProviderServices, EntityFramework.SqlServer" />
    </providers>
  </entityFramework>
</configuration>`
  },

  // 4. Global.asax
  {
    path: 'Global.asax',
    name: 'Global.asax',
    category: 'Config',
    language: 'xml',
    description: 'ASP.NET application entry point markup linking to Global.asax.cs.',
    content: `<%@ Application Codebehind="Global.asax.cs" Inherits="BookNest.MvcApplication" Language="C#" %>`
  },

  // 5. Global.asax.cs
  {
    path: 'Global.asax.cs',
    name: 'Global.asax.cs',
    category: 'Config',
    language: 'csharp',
    description: 'Application startup handler registering routes, filters, and database initializer.',
    content: `using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Data.Entity;
using BookNest.Models;

namespace BookNest
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            // Optional EF Database Initializer to seed initial data
            Database.SetInitializer(new BookNestDbInitializer());
        }
    }
}`
  },

  // 4. App_Start/RouteConfig.cs
  {
    path: 'App_Start/RouteConfig.cs',
    name: 'RouteConfig.cs',
    category: 'Config',
    language: 'csharp',
    description: 'Configures default URL routing pattern ({controller}/{action}/{id}).',
    content: `using System.Web.Mvc;
using System.Web.Routing;

namespace BookNest
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}`
  },

  // 5. Models/Book.cs
  {
    path: 'Models/Book.cs',
    name: 'Book.cs',
    category: 'Model',
    language: 'csharp',
    description: 'Represents a book entity in the SQL Server database with data annotations.',
    content: `using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookNest.Models
{
    [Table("Books")]
    public class Book
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Book ID")]
        public int BookId { get; set; }

        [Required(ErrorMessage = "Book Name is required")]
        [StringLength(150, ErrorMessage = "Book name cannot exceed 150 characters")]
        [Display(Name = "Book Title")]
        public string BookName { get; set; }

        [Required(ErrorMessage = "Author name is required")]
        [StringLength(100)]
        [Display(Name = "Author")]
        public string Author { get; set; }

        [Required(ErrorMessage = "Category is required")]
        [StringLength(50)]
        [Display(Name = "Category")]
        public string Category { get; set; }

        [Required(ErrorMessage = "Price is required")]
        [Range(1, 10000, ErrorMessage = "Price must be between ₹1 and ₹10,000")]
        [DataType(DataType.Currency)]
        [Display(Name = "Price (₹)")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Description is required")]
        [StringLength(1000)]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Display(Name = "Cover Image URL")]
        public string ImageUrl { get; set; }

        [Required]
        [Range(0, 1000)]
        [Display(Name = "Stock Quantity")]
        public int StockQuantity { get; set; }
    }
}`
  },

  // 6. Models/ContactMessage.cs
  {
    path: 'Models/ContactMessage.cs',
    name: 'ContactMessage.cs',
    category: 'Model',
    language: 'csharp',
    description: 'Represents inquiry messages sent by users via the Contact Us form.',
    content: `using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookNest.Models
{
    [Table("ContactMessages")]
    public class ContactMessage
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [StringLength(100)]
        [Display(Name = "Your Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [StringLength(120)]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your phone number")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Phone number must be exactly 10 digits")]
        [Display(Name = "Mobile Number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [StringLength(1000, MinimumLength = 10, ErrorMessage = "Message must be between 10 and 1000 characters")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Your Message")]
        public string Message { get; set; }

        [Display(Name = "Submitted Date")]
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}`
  },

  // 7. Models/Order.cs & OrderDetail.cs
  {
    path: 'Models/Order.cs',
    name: 'Order.cs',
    category: 'Model',
    language: 'csharp',
    description: 'Entity representing customer orders and associated metadata.',
    content: `using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookNest.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderId { get; set; }

        [Required(ErrorMessage = "Full Name is required")]
        [StringLength(100)]
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        [StringLength(120)]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone is required")]
        [StringLength(15)]
        [Display(Name = "Phone Number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Delivery address is required")]
        [StringLength(300)]
        [Display(Name = "Shipping Address")]
        public string Address { get; set; }

        [Display(Name = "Order Date")]
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Display(Name = "Total Amount (₹)")]
        [DataType(DataType.Currency)]
        public decimal TotalAmount { get; set; }

        [StringLength(50)]
        [Display(Name = "Status")]
        public string Status { get; set; } = "Confirmed";

        // Navigation property for child order items
        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}`
  },

  {
    path: 'Models/OrderDetail.cs',
    name: 'OrderDetail.cs',
    category: 'Model',
    language: 'csharp',
    description: 'Line item entity mapping purchased books to a specific order.',
    content: `using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookNest.Models
{
    [Table("OrderDetails")]
    public class OrderDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderDetailId { get; set; }

        [Required]
        [ForeignKey("Order")]
        public int OrderId { get; set; }

        [Required]
        [ForeignKey("Book")]
        public int BookId { get; set; }

        [Required]
        [Range(1, 100)]
        public int Quantity { get; set; }

        [Required]
        public decimal Price { get; set; }

        // Navigation properties
        public virtual Order Order { get; set; }
        public virtual Book Book { get; set; }
    }
}`
  },

  // 8. Models/CartItem.cs
  {
    path: 'Models/CartItem.cs',
    name: 'CartItem.cs',
    category: 'Model',
    language: 'csharp',
    description: 'ViewModel stored in Session["Cart"] representing items in shopping cart.',
    content: `namespace BookNest.Models
{
    public class CartItem
    {
        public Book Book { get; set; }
        public int Quantity { get; set; }

        public decimal Subtotal
        {
            get { return Book != null ? Book.Price * Quantity : 0; }
        }
    }
}`
  },

  // 9. Models/BookNestDbContext.cs
  {
    path: 'Models/BookNestDbContext.cs',
    name: 'BookNestDbContext.cs',
    category: 'Model',
    language: 'csharp',
    description: 'Entity Framework 6 DbContext handling database connectivity and seed data.',
    content: `using System;
using System.Data.Entity;

namespace BookNest.Models
{
    public class BookNestDbContext : DbContext
    {
        // Passes the connection string name defined in Web.config
        public BookNestDbContext() : base("name=BookNestDbContext")
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<ContactMessage> ContactMessages { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }
    }

    // Seed database automatically on first run
    public class BookNestDbInitializer : CreateDatabaseIfNotExists<BookNestDbContext>
    {
        protected override void Seed(BookNestDbContext context)
        {
            context.Books.Add(new Book
            {
                BookName = "Clean Code",
                Author = "Robert C. Martin",
                Category = "Programming",
                Price = 599,
                Description = "A Handbook of Agile Software Craftsmanship. Learn the principles of writing clean, maintainable code.",
                ImageUrl = "https://images.unsplash.com/photo-1532012164546-f432f2e3777a?w=400",
                StockQuantity = 15
            });

            context.Books.Add(new Book
            {
                BookName = "The Pragmatic Programmer",
                Author = "Andrew Hunt",
                Category = "Programming",
                Price = 699,
                Description = "Your journey to mastery in modern software architecture, debugging, and teamwork.",
                ImageUrl = "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
                StockQuantity = 12
            });

            context.Books.Add(new Book
            {
                BookName = "Java: The Complete Reference",
                Author = "Herbert Schildt",
                Category = "Programming",
                Price = 799,
                Description = "Comprehensive coverage of Java syntax, OOP, Multithreading, and Collections Framework.",
                ImageUrl = "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
                StockQuantity = 20
            });

            context.Books.Add(new Book
            {
                BookName = "Atomic Habits",
                Author = "James Clear",
                Category = "Self Help",
                Price = 499,
                Description = "An easy and proven way to build good habits and break bad ones.",
                ImageUrl = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
                StockQuantity = 25
            });

            context.SaveChanges();
            base.Seed(context);
        }
    }
}`
  },

  // 10. Controllers/HomeController.cs
  {
    path: 'Controllers/HomeController.cs',
    name: 'HomeController.cs',
    category: 'Controller',
    language: 'csharp',
    description: 'Handles the Home landing page, featured books, and About Us page.',
    content: `using System.Linq;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class HomeController : Controller
    {
        private readonly BookNestDbContext _db = new BookNestDbContext();

        // GET: Home/Index
        public ActionResult Index()
        {
            // Fetch top 4 featured books for homepage showcase
            var featuredBooks = _db.Books.Take(4).ToList();
            return View(featuredBooks);
        }

        // GET: Home/About
        public ActionResult About()
        {
            ViewBag.Message = "About BookNest – BCA Mini Project";
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}`
  },

  // 11. Controllers/BooksController.cs
  {
    path: 'Controllers/BooksController.cs',
    name: 'BooksController.cs',
    category: 'Controller',
    language: 'csharp',
    description: 'Manages book catalog browsing, category filtering, search, and book details.',
    content: `using System.Linq;
using System.Net;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookNestDbContext _db = new BookNestDbContext();

        // GET: Books (with optional search and category filter)
        public ActionResult Index(string searchString, string category)
        {
            var books = from b in _db.Books select b;

            // Search filter by title or author
            if (!string.IsNullOrEmpty(searchString))
            {
                books = books.Where(b => b.BookName.Contains(searchString) || b.Author.Contains(searchString));
            }

            // Category filter
            if (!string.IsNullOrEmpty(category) && category != "All")
            {
                books = books.Where(b => b.Category == category);
            }

            ViewBag.CurrentCategory = category ?? "All";
            ViewBag.CurrentSearch = searchString;

            // Distinct categories for dropdown / pill filters
            ViewBag.Categories = _db.Books.Select(b => b.Category).Distinct().ToList();

            return View(books.ToList());
        }

        // GET: Books/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Book book = _db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }

            return View(book);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}`
  },

  // 12. Controllers/CartController.cs
  {
    path: 'Controllers/CartController.cs',
    name: 'CartController.cs',
    category: 'Controller',
    language: 'csharp',
    description: 'Handles shopping cart session management (Add, Remove, Update quantity, Grand total).',
    content: `using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class CartController : Controller
    {
        private readonly BookNestDbContext _db = new BookNestDbContext();

        // Helper method to retrieve cart from Session
        private List<CartItem> GetCart()
        {
            if (Session["Cart"] == null)
            {
                Session["Cart"] = new List<CartItem>();
            }
            return (List<CartItem>)Session["Cart"];
        }

        // GET: Cart
        public ActionResult Index()
        {
            var cart = GetCart();
            ViewBag.GrandTotal = cart.Sum(item => item.Subtotal);
            return View(cart);
        }

        // POST: Cart/AddToCart/5
        [HttpPost]
        public ActionResult AddToCart(int id, int quantity = 1)
        {
            var book = _db.Books.Find(id);
            if (book != null)
            {
                var cart = GetCart();
                var existingItem = cart.FirstOrDefault(c => c.Book.BookId == id);

                if (existingItem != null)
                {
                    existingItem.Quantity += quantity;
                }
                else
                {
                    cart.Add(new CartItem { Book = book, Quantity = quantity });
                }

                Session["Cart"] = cart;
                TempData["SuccessMessage"] = $"'{book.BookName}' added to cart successfully!";
            }

            return RedirectToAction("Index");
        }

        // POST: Cart/UpdateQuantity
        [HttpPost]
        public ActionResult UpdateQuantity(int id, int quantity)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(c => c.Book.BookId == id);

            if (item != null)
            {
                if (quantity > 0)
                {
                    item.Quantity = quantity;
                }
                else
                {
                    cart.Remove(item);
                }
            }

            Session["Cart"] = cart;
            return RedirectToAction("Index");
        }

        // POST: Cart/RemoveFromCart/5
        [HttpPost]
        public ActionResult RemoveFromCart(int id)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(c => c.Book.BookId == id);

            if (item != null)
            {
                cart.Remove(item);
                Session["Cart"] = cart;
                TempData["InfoMessage"] = "Item removed from cart.";
            }

            return RedirectToAction("Index");
        }

        // POST: Cart/ClearCart
        public ActionResult ClearCart()
        {
            Session["Cart"] = null;
            return RedirectToAction("Index");
        }
    }
}`
  },

  // 13. Controllers/ContactController.cs
  {
    path: 'Controllers/ContactController.cs',
    name: 'ContactController.cs',
    category: 'Controller',
    language: 'csharp',
    description: 'Manages user inquiry submission with model state validation and SQL insertion.',
    content: `using System;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class ContactController : Controller
    {
        private readonly BookNestDbContext _db = new BookNestDbContext();

        // GET: Contact
        public ActionResult Index()
        {
            return View();
        }

        // POST: Contact
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "Name,Email,Phone,Message")] ContactMessage contact)
        {
            if (ModelState.IsValid)
            {
                contact.CreatedDate = DateTime.Now;
                _db.ContactMessages.Add(contact);
                _db.SaveChanges();

                TempData["SuccessMessage"] = "Thank you! Your message has been received. Our team will contact you shortly.";
                return RedirectToAction("Index");
            }

            // If validation failed, re-display form with error messages
            return View(contact);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}`
  },

  // 14. Controllers/OrderController.cs
  {
    path: 'Controllers/OrderController.cs',
    name: 'OrderController.cs',
    category: 'Controller',
    language: 'csharp',
    description: 'Handles order checkout simulation, stores Order & OrderDetails in database.',
    content: `using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using BookNest.Models;

namespace BookNest.Controllers
{
    public class OrderController : Controller
    {
        private readonly BookNestDbContext _db = new BookNestDbContext();

        // GET: Order/Checkout
        public ActionResult Checkout()
        {
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null || !cart.Any())
            {
                TempData["ErrorMessage"] = "Your cart is empty. Please add books before checkout.";
                return RedirectToAction("Index", "Books");
            }

            ViewBag.Cart = cart;
            ViewBag.GrandTotal = cart.Sum(i => i.Subtotal);

            return View(new Order());
        }

        // POST: Order/Checkout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkout(Order order)
        {
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null || !cart.Any())
            {
                return RedirectToAction("Index", "Books");
            }

            if (ModelState.IsValid)
            {
                order.OrderDate = DateTime.Now;
                order.TotalAmount = cart.Sum(i => i.Subtotal);
                order.Status = "Confirmed";

                // Save Order master record
                _db.Orders.Add(order);
                _db.SaveChanges();

                // Save OrderDetail records for each cart item
                foreach (var item in cart)
                {
                    var detail = new OrderDetail
                    {
                        OrderId = order.OrderId,
                        BookId = item.Book.BookId,
                        Quantity = item.Quantity,
                        Price = item.Book.Price
                    };
                    _db.OrderDetails.Add(detail);

                    // Optional: Deduct stock
                    var bookInDb = _db.Books.Find(item.Book.BookId);
                    if (bookInDb != null)
                    {
                        bookInDb.StockQuantity = Math.Max(0, bookInDb.StockQuantity - item.Quantity);
                    }
                }

                _db.SaveChanges();

                // Clear the session cart
                Session["Cart"] = null;

                // Redirect to confirmation page
                return RedirectToAction("OrderSuccess", new { id = order.OrderId });
            }

            ViewBag.Cart = cart;
            ViewBag.GrandTotal = cart.Sum(i => i.Subtotal);
            return View(order);
        }

        // GET: Order/OrderSuccess/5
        public ActionResult OrderSuccess(int id)
        {
            var order = _db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }

            return View(order);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}`
  },

  // 15. Views/Shared/_Layout.cshtml
  {
    path: 'Views/Shared/_Layout.cshtml',
    name: '_Layout.cshtml',
    category: 'View',
    language: 'html',
    description: 'Master Razor layout template containing navigation bar, cart counter, and footer.',
    content: `@using BookNest.Models
@{
    var cart = Session["Cart"] as List<CartItem>;
    int cartCount = cart != null ? cart.Sum(i => i.Quantity) : 0;
}
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@ViewBag.Title - BookNest Online Bookstore</title>
    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="~/Content/Site.css" rel="stylesheet" />
</head>
<body>
    <!-- Top Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-warning d-flex align-items-center gap-2" href="@Url.Action("Index", "Home")">
                <i class="bi bi-book-half fs-4"></i>
                <span>BookNest</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="@Url.Action("Index", "Home")"><i class="bi bi-house-door me-1"></i>Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="@Url.Action("Index", "Books")"><i class="bi bi-grid me-1"></i>Books Catalog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="@Url.Action("About", "Home")"><i class="bi bi-info-circle me-1"></i>About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="@Url.Action("Index", "Contact")"><i class="bi bi-envelope me-1"></i>Contact Us</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <a href="@Url.Action("Index", "Cart")" class="btn btn-outline-warning position-relative px-3">
                        <i class="bi bi-cart3 me-1"></i>Cart
                        @if (cartCount > 0)
                        {
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                @cartCount
                            </span>
                        }
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Body Container -->
    <div class="container body-content py-4">
        @if (TempData["SuccessMessage"] != null)
        {
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>@TempData["SuccessMessage"]
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        }
        @if (TempData["ErrorMessage"] != null)
        {
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>@TempData["ErrorMessage"]
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        }
        @RenderBody()
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4 mt-5 border-top border-secondary">
        <div class="container text-center">
            <p class="mb-1">&copy; @DateTime.Now.Year BookNest – Online Book Store | Developed as BCA Mini Project</p>
            <small class="text-muted">Built with ASP.NET MVC (.NET Framework 4.8), Entity Framework 6 & SQL Server LocalDB</small>
        </div>
    </footer>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @RenderSection("scripts", required: false)
</body>
</html>`
  },

  // 16. Views/Home/Index.cshtml
  {
    path: 'Views/Home/Index.cshtml',
    name: 'Index.cshtml (Home)',
    category: 'View',
    language: 'html',
    description: 'Homepage view featuring hero banner, categories, and featured books.',
    content: `@model IEnumerable<BookNest.Models.Book>
@{
    ViewBag.Title = "Home";
}

<!-- Hero Section -->
<div class="p-5 mb-4 bg-light rounded-3 shadow-sm border">
    <div class="container-fluid py-3">
        <span class="badge bg-primary mb-2 px-3 py-2">BCA Mini Project</span>
        <h1 class="display-5 fw-bold text-dark">Welcome to BookNest</h1>
        <p class="col-md-8 fs-5 text-muted">
            Discover your next favorite academic and tech book. Browse through our curated selection of Computer Science, Programming, and Self-Development literature with instant cart checkout.
        </p>
        <div class="d-flex gap-2 mt-4">
            <a href="@Url.Action("Index", "Books")" class="btn btn-warning btn-lg px-4 fw-semibold">
                <i class="bi bi-book me-2"></i>Browse All Books
            </a>
            <a href="@Url.Action("About", "Home")" class="btn btn-outline-secondary btn-lg px-4">
                Learn About Project
            </a>
        </div>
    </div>
</div>

<!-- Featured Books Section -->
<div class="my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-0">Featured Books</h2>
            <p class="text-muted">Handpicked recommendations for technology students</p>
        </div>
        <a href="@Url.Action("Index", "Books")" class="btn btn-outline-primary">View All <i class="bi bi-arrow-right"></i></a>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        @foreach (var item in Model)
        {
            <div class="col">
                <div class="card h-100 shadow-sm border-0">
                    <img src="@item.ImageUrl" class="card-img-top book-card-img" alt="@item.BookName" style="height: 240px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-secondary mb-2 align-self-start">@item.Category</span>
                        <h5 class="card-title text-truncate" title="@item.BookName">@item.BookName</h5>
                        <p class="card-text text-muted small mb-2">By @item.Author</p>
                        <h4 class="text-primary fw-bold mt-auto mb-3">₹@item.Price</h4>
                        <div class="d-grid gap-2">
                            <a href="@Url.Action("Details", "Books", new { id = item.BookId })" class="btn btn-outline-dark btn-sm">
                                View Details
                            </a>
                            @using (Html.BeginForm("AddToCart", "Cart", new { id = item.BookId }, FormMethod.Post))
                            {
                                <button type="submit" class="btn btn-warning btn-sm w-100 fw-semibold">
                                    <i class="bi bi-cart-plus me-1"></i>Add to Cart
                                </button>
                            }
                        </div>
                    </div>
                </div>
            </div>
        }
    </div>
</div>`
  },

  // 17. Views/Books/Index.cshtml
  {
    path: 'Views/Books/Index.cshtml',
    name: 'Index.cshtml (Books)',
    category: 'View',
    language: 'html',
    description: 'Books catalog view with category filtering, search input, and responsive cards.',
    content: `@model IEnumerable<BookNest.Models.Book>
@{
    ViewBag.Title = "Books Catalog";
    var categories = ViewBag.Categories as List<string>;
    string currentCat = ViewBag.CurrentCategory as string;
    string currentSearch = ViewBag.CurrentSearch as string;
}

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="fw-bold mb-1">Books Catalog</h2>
        <p class="text-muted mb-0">Explore our complete collection of textbooks and guides</p>
    </div>
    
    <!-- Search Form -->
    @using (Html.BeginForm("Index", "Books", FormMethod.Get, new { @class = "d-flex gap-2" }))
    {
        <input type="hidden" name="category" value="@currentCat" />
        <input type="text" name="searchString" class="form-control" placeholder="Search title or author..." value="@currentSearch" style="min-width: 250px;" />
        <button type="submit" class="btn btn-dark"><i class="bi bi-search"></i></button>
        if (!string.IsNullOrEmpty(currentSearch) || currentCat != "All")
        {
            <a href="@Url.Action("Index", "Books")" class="btn btn-outline-secondary" title="Reset Filters"><i class="bi bi-x-circle"></i></a>
        }
    }
</div>

<!-- Category Filter Pills -->
<div class="mb-4 d-flex gap-2 flex-wrap">
    <a href="@Url.Action("Index", "Books", new { category = "All", searchString = currentSearch })" 
       class="btn btn-sm @(currentCat == "All" ? "btn-dark" : "btn-outline-secondary")">
        All Categories
    </a>
    @if (categories != null)
    {
        foreach (var cat in categories)
        {
            <a href="@Url.Action("Index", "Books", new { category = cat, searchString = currentSearch })" 
               class="btn btn-sm @(currentCat == cat ? "btn-dark" : "btn-outline-secondary")">
                @cat
            </a>
        }
    }
</div>

<!-- Books Grid -->
@if (!Model.Any())
{
    <div class="alert alert-info text-center py-5">
        <i class="bi bi-emoji-neutral fs-1 d-block mb-3"></i>
        <h5>No books found matching your criteria.</h5>
        <p>Try searching with another keyword or selecting "All Categories".</p>
        <a href="@Url.Action("Index", "Books")" class="btn btn-primary mt-2">Clear Search</a>
    </div>
}
else
{
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        @foreach (var item in Model)
        {
            <div class="col">
                <div class="card h-100 shadow-sm border-0 position-relative">
                    <img src="@item.ImageUrl" class="card-img-top" alt="@item.BookName" style="height: 240px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge bg-secondary">@item.Category</span>
                            <span class="badge @(item.StockQuantity > 0 ? "bg-success-subtle text-success" : "bg-danger-subtle text-danger")">
                                @(item.StockQuantity > 0 ? "In Stock" : "Out of Stock")
                            </span>
                        </div>
                        <h6 class="card-title fw-bold text-truncate" title="@item.BookName">@item.BookName</h6>
                        <p class="card-text text-muted small mb-2">By @item.Author</p>
                        <h4 class="text-primary fw-bold mt-auto mb-3">₹@item.Price</h4>
                        <div class="d-grid gap-2">
                            <a href="@Url.Action("Details", "Books", new { id = item.BookId })" class="btn btn-outline-dark btn-sm">
                                View Details
                            </a>
                            @using (Html.BeginForm("AddToCart", "Cart", new { id = item.BookId }, FormMethod.Post))
                            {
                                <button type="submit" class="btn btn-warning btn-sm w-100 fw-semibold" @(item.StockQuantity <= 0 ? "disabled" : "")>
                                    <i class="bi bi-cart-plus me-1"></i>Add to Cart
                                </button>
                            }
                        </div>
                    </div>
                </div>
            </div>
        }
    </div>
}`
  },

  // 18. Views/Books/Details.cshtml
  {
    path: 'Views/Books/Details.cshtml',
    name: 'Details.cshtml (Book)',
    category: 'View',
    language: 'html',
    description: 'Detailed view of a single book with metadata, stock count, and quantity input.',
    content: `@model BookNest.Models.Book
@{
    ViewBag.Title = Model.BookName;
}

<nav aria-label="breadcrumb" class="mb-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="@Url.Action("Index", "Home")">Home</a></li>
        <li class="breadcrumb-item"><a href="@Url.Action("Index", "Books")">Books</a></li>
        <li class="breadcrumb-item active">@Model.BookName</li>
    </ol>
</nav>

<div class="card shadow-sm border-0 p-4">
    <div class="row g-4">
        <div class="col-md-4 text-center">
            <img src="@Model.ImageUrl" class="img-fluid rounded shadow" alt="@Model.BookName" style="max-height: 420px; object-fit: cover;">
        </div>
        <div class="col-md-8">
            <span class="badge bg-primary mb-2">@Model.Category</span>
            <h2 class="fw-bold mb-2">@Model.BookName</h2>
            <h5 class="text-muted mb-3">Written by: <strong class="text-dark">@Model.Author</strong></h5>
            
            <div class="my-3">
                <h3 class="text-success fw-bold">₹@Model.Price</h3>
                <p class="text-muted small">Inclusive of all college/lab student discounts & taxes</p>
            </div>

            <div class="mb-3">
                <strong>Availability: </strong>
                @if (Model.StockQuantity > 0)
                {
                    <span class="text-success fw-semibold"><i class="bi bi-check-circle-fill me-1"></i>In Stock (@Model.StockQuantity copies available)</span>
                }
                else
                {
                    <span class="text-danger fw-semibold"><i class="bi bi-x-circle-fill me-1"></i>Currently Out of Stock</span>
                }
            </div>

            <div class="mb-4">
                <h6 class="fw-bold">Description:</h6>
                <p class="text-secondary leading-relaxed">@Model.Description</p>
            </div>

            @if (Model.StockQuantity > 0)
            {
                using (Html.BeginForm("AddToCart", "Cart", new { id = Model.BookId }, FormMethod.Post, new { @class = "row g-3 align-items-center" }))
                {
                    <div class="col-auto">
                        <label for="quantity" class="col-form-label fw-bold">Quantity:</label>
                    </div>
                    <div class="col-auto">
                        <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" max="@Model.StockQuantity" style="width: 90px;" />
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-warning btn-lg px-4 fw-semibold">
                            <i class="bi bi-cart-plus me-2"></i>Add to Cart
                        </button>
                    </div>
                }
            }
            
            <div class="mt-4 pt-3 border-top">
                <a href="@Url.Action("Index", "Books")" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Back to Books
                </a>
            </div>
        </div>
    </div>
</div>`
  },

  // 19. Views/Cart/Index.cshtml
  {
    path: 'Views/Cart/Index.cshtml',
    name: 'Index.cshtml (Cart)',
    category: 'View',
    language: 'html',
    description: 'Shopping cart view displaying line items, quantity modifiers, and checkout CTA.',
    content: `@model List<BookNest.Models.CartItem>
@{
    ViewBag.Title = "Your Shopping Cart";
    decimal grandTotal = ViewBag.GrandTotal != null ? (decimal)ViewBag.GrandTotal : 0;
}

<h2 class="fw-bold mb-4"><i class="bi bi-cart3 me-2"></i>Shopping Cart</h2>

@if (Model == null || !Model.Any())
{
    <div class="card p-5 text-center shadow-sm border-0">
        <i class="bi bi-cart-x text-muted" style="font-size: 4rem;"></i>
        <h4 class="mt-3">Your Cart is Currently Empty</h4>
        <p class="text-muted">Looks like you haven't added any books to your cart yet.</p>
        <div class="mt-3">
            <a href="@Url.Action("Index", "Books")" class="btn btn-warning btn-lg px-4 fw-semibold">
                Explore Books Catalog
            </a>
        </div>
    </div>
}
else
{
    <div class="row g-4">
        <!-- Cart Items Table -->
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Book</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach (var item in Model)
                            {
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-3">
                                            <img src="@item.Book.ImageUrl" alt="@item.Book.BookName" style="width: 50px; height: 65px; object-fit: cover;" class="rounded" />
                                            <div>
                                                <h6 class="mb-0 fw-bold">@item.Book.BookName</h6>
                                                <small class="text-muted">@item.Book.Author</small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>₹@item.Book.Price</td>
                                    <td>
                                        @using (Html.BeginForm("UpdateQuantity", "Cart", FormMethod.Post, new { @class = "d-flex align-items-center gap-1" }))
                                        {
                                            <input type="hidden" name="id" value="@item.Book.BookId" />
                                            <input type="number" name="quantity" value="@item.Quantity" min="1" max="20" class="form-control form-control-sm" style="width: 65px;" />
                                            <button type="submit" class="btn btn-outline-secondary btn-sm" title="Update"><i class="bi bi-arrow-repeat"></i></button>
                                        }
                                    </td>
                                    <td class="fw-bold text-primary">₹@item.Subtotal</td>
                                    <td>
                                        @using (Html.BeginForm("RemoveFromCart", "Cart", new { id = item.Book.BookId }, FormMethod.Post))
                                        {
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Remove Item">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        }
                                    </td>
                                </tr>
                            }
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-3">
                <a href="@Url.Action("Index", "Books")" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Continue Shopping
                </a>
                <a href="@Url.Action("ClearCart", "Cart")" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure you want to clear your cart?');">
                    Clear Entire Cart
                </a>
            </div>
        </div>

        <!-- Order Summary Card -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 p-4">
                <h5 class="fw-bold mb-3">Order Summary</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Items Subtotal:</span>
                    <span>₹@grandTotal</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Standard Delivery:</span>
                    <span class="text-success fw-semibold">FREE</span>
                </div>
                <hr />
                <div class="d-flex justify-content-between mb-4">
                    <span class="fw-bold fs-5">Grand Total:</span>
                    <span class="fw-bold fs-5 text-primary">₹@grandTotal</span>
                </div>
                <a href="@Url.Action("Checkout", "Order")" class="btn btn-warning btn-lg w-100 fw-bold py-2">
                    Proceed to Checkout <i class="bi bi-arrow-right ms-1"></i>
                </a>
                <p class="text-muted text-center small mt-3 mb-0">
                    <i class="bi bi-shield-check me-1"></i>Safe & simulated checkout for college evaluation
                </p>
            </div>
        </div>
    </div>
}`
  },

  // 20. Views/Contact/Index.cshtml
  {
    path: 'Views/Contact/Index.cshtml',
    name: 'Index.cshtml (Contact)',
    category: 'View',
    language: 'html',
    description: 'Contact Us form with client & server-side validation and store details.',
    content: `@model BookNest.Models.ContactMessage
@{
    ViewBag.Title = "Contact Us";
}

<div class="row g-5">
    <div class="col-lg-6">
        <h2 class="fw-bold mb-3">Get in Touch with BookNest</h2>
        <p class="text-muted">Have questions regarding book availability, orders, or your BCA college project? Fill out the form and our team will get back to you promptly.</p>

        <div class="card p-4 border-0 shadow-sm mt-4">
            @using (Html.BeginForm("Index", "Contact", FormMethod.Post))
            {
                @Html.AntiForgeryToken()
                @Html.ValidationSummary(true, "", new { @class = "text-danger" })

                <div class="mb-3">
                    @Html.LabelFor(m => m.Name, new { @class = "form-label fw-bold" })
                    @Html.TextBoxFor(m => m.Name, new { @class = "form-control", placeholder = "Enter your full name" })
                    @Html.ValidationMessageFor(m => m.Name, "", new { @class = "text-danger small" })
                </div>

                <div class="mb-3">
                    @Html.LabelFor(m => m.Email, new { @class = "form-label fw-bold" })
                    @Html.TextBoxFor(m => m.Email, new { @class = "form-control", placeholder = "name@example.com" })
                    @Html.ValidationMessageFor(m => m.Email, "", new { @class = "text-danger small" })
                </div>

                <div class="mb-3">
                    @Html.LabelFor(m => m.Phone, new { @class = "form-label fw-bold" })
                    @Html.TextBoxFor(m => m.Phone, new { @class = "form-control", placeholder = "10-digit mobile number" })
                    @Html.ValidationMessageFor(m => m.Phone, "", new { @class = "text-danger small" })
                </div>

                <div class="mb-3">
                    @Html.LabelFor(m => m.Message, new { @class = "form-label fw-bold" })
                    @Html.TextAreaFor(m => m.Message, new { @class = "form-control", rows = 4, placeholder = "How can we help you?" })
                    @Html.ValidationMessageFor(m => m.Message, "", new { @class = "text-danger small" })
                </div>

                <button type="submit" class="btn btn-warning btn-lg w-100 fw-bold">
                    <i class="bi bi-send me-1"></i>Send Message
                </button>
            }
        </div>
    </div>

    <div class="col-lg-6">
        <h4 class="fw-bold mb-4">Store & Project Location</h4>
        <div class="card p-4 border-0 shadow-sm mb-4">
            <div class="d-flex align-items-start gap-3 mb-3">
                <i class="bi bi-geo-alt-fill fs-3 text-primary"></i>
                <div>
                    <h6 class="fw-bold mb-1">Campus Address</h6>
                    <p class="text-muted mb-0">Department of Computer Applications (BCA), College Tech Campus, Knowledge Park, India</p>
                </div>
            </div>
            <div class="d-flex align-items-start gap-3 mb-3">
                <i class="bi bi-telephone-fill fs-3 text-primary"></i>
                <div>
                    <h6 class="fw-bold mb-1">Helpline</h6>
                    <p class="text-muted mb-0">+91 98765 43210 (Mon-Sat, 9AM - 5PM)</p>
                </div>
            </div>
            <div class="d-flex align-items-start gap-3">
                <i class="bi bi-envelope-fill fs-3 text-primary"></i>
                <div>
                    <h6 class="fw-bold mb-1">Email Inquiry</h6>
                    <p class="text-muted mb-0">support@booknest-bca.edu.in</p>
                </div>
            </div>
        </div>

        <div class="card bg-light border-0 p-4">
            <h6 class="fw-bold mb-2"><i class="bi bi-info-circle me-1"></i>BCA Viva Note:</h6>
            <p class="text-muted small mb-0">
                When you click "Send Message", ASP.NET MVC validates the model attributes (<code>[Required]</code>, <code>[EmailAddress]</code>, <code>[RegularExpression]</code>) and executes <code>_db.ContactMessages.Add(contact)</code> using Entity Framework.
            </p>
        </div>
    </div>
</div>`
  },

  // 21. Views/Order/Checkout.cshtml
  {
    path: 'Views/Order/Checkout.cshtml',
    name: 'Checkout.cshtml',
    category: 'View',
    language: 'html',
    description: 'Simulated checkout page capturing customer details and placing orders.',
    content: `@model BookNest.Models.Order
@using BookNest.Models
@{
    ViewBag.Title = "Checkout Order";
    var cart = ViewBag.Cart as List<CartItem>;
    decimal grandTotal = ViewBag.GrandTotal != null ? (decimal)ViewBag.GrandTotal : 0;
}

<h2 class="fw-bold mb-4"><i class="bi bi-credit-card me-2"></i>Order Checkout</h2>

<div class="row g-4">
    <!-- Customer Details Form -->
    <div class="col-lg-7">
        <div class="card p-4 shadow-sm border-0">
            <h5 class="fw-bold mb-3">Shipping & Customer Information</h5>
            @using (Html.BeginForm("Checkout", "Order", FormMethod.Post))
            {
                @Html.AntiForgeryToken()
                @Html.ValidationSummary(true, "", new { @class = "text-danger" })

                <div class="mb-3">
                    @Html.LabelFor(m => m.CustomerName, new { @class = "form-label fw-bold" })
                    @Html.TextBoxFor(m => m.CustomerName, new { @class = "form-control", placeholder = "Your full name" })
                    @Html.ValidationMessageFor(m => m.CustomerName, "", new { @class = "text-danger small" })
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        @Html.LabelFor(m => m.Email, new { @class = "form-label fw-bold" })
                        @Html.TextBoxFor(m => m.Email, new { @class = "form-control", placeholder = "name@example.com" })
                        @Html.ValidationMessageFor(m => m.Email, "", new { @class = "text-danger small" })
                    </div>
                    <div class="col-md-6 mb-3">
                        @Html.LabelFor(m => m.Phone, new { @class = "form-label fw-bold" })
                        @Html.TextBoxFor(m => m.Phone, new { @class = "form-control", placeholder = "10-digit mobile number" })
                        @Html.ValidationMessageFor(m => m.Phone, "", new { @class = "text-danger small" })
                    </div>
                </div>

                <div class="mb-3">
                    @Html.LabelFor(m => m.Address, new { @class = "form-label fw-bold" })
                    @Html.TextAreaFor(m => m.Address, new { @class = "form-control", rows = 3, placeholder = "Complete postal address with pincode" })
                    @Html.ValidationMessageFor(m => m.Address, "", new { @class = "text-danger small" })
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Payment Method:</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="cod" checked>
                        <label class="form-check-label" for="cod">
                            Cash on Delivery (Simulated for college project)
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="upi">
                        <label class="form-check-label" for="upi">
                            Simulated UPI / Net Banking (No real payment gateway required)
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn btn-success btn-lg w-100 fw-bold py-2">
                    <i class="bi bi-bag-check me-2"></i>Confirm & Place Order (₹@grandTotal)
                </button>
            }
        </div>
    </div>

    <!-- Order Items Review -->
    <div class="col-lg-5">
        <div class="card p-4 shadow-sm border-0">
            <h5 class="fw-bold mb-3">Order Summary</h5>
            <ul class="list-group list-group-flush mb-3">
                @if (cart != null)
                {
                    foreach (var item in cart)
                    {
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            <div>
                                <h6 class="my-0">@item.Book.BookName</h6>
                                <small class="text-muted">Qty: @item.Quantity × ₹@item.Book.Price</small>
                            </div>
                            <span class="text-muted fw-bold">₹@item.Subtotal</span>
                        </li>
                    }
                }
                <li class="list-group-item d-flex justify-content-between px-0 fw-bold fs-5 text-primary">
                    <span>Total (INR):</span>
                    <span>₹@grandTotal</span>
                </li>
            </ul>
        </div>
    </div>
</div>`
  },

  // 22. Views/Order/OrderSuccess.cshtml
  {
    path: 'Views/Order/OrderSuccess.cshtml',
    name: 'OrderSuccess.cshtml',
    category: 'View',
    language: 'html',
    description: 'Confirmation receipt page generated after successful order placement.',
    content: `@model BookNest.Models.Order
@{
    ViewBag.Title = "Order Placed Successfully";
}

<div class="row justify-content-center">
    <div class="col-md-8 text-center">
        <div class="card p-5 shadow-sm border-0">
            <div class="text-success mb-3">
                <i class="bi bi-check-circle-fill" style="font-size: 4.5rem;"></i>
            </div>
            <h2 class="fw-bold text-dark">Thank You for Your Order!</h2>
            <p class="lead text-muted">Your order has been recorded into the BookNest SQL Server database.</p>
            
            <div class="alert alert-light border my-4 text-start">
                <div class="row">
                    <div class="col-sm-6 mb-2">
                        <strong>Order ID:</strong> #BN-@Model.OrderId.ToString("D5")
                    </div>
                    <div class="col-sm-6 mb-2">
                        <strong>Order Date:</strong> @Model.OrderDate.ToString("f")
                    </div>
                    <div class="col-sm-6 mb-2">
                        <strong>Customer:</strong> @Model.CustomerName
                    </div>
                    <div class="col-sm-6 mb-2">
                        <strong>Total Amount:</strong> ₹@Model.TotalAmount
                    </div>
                    <div class="col-12">
                        <strong>Shipping To:</strong> @Model.Address
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-center gap-3">
                <a href="@Url.Action("Index", "Books")" class="btn btn-warning px-4 fw-semibold">
                    <i class="bi bi-book me-1"></i>Continue Shopping
                </a>
                <a href="@Url.Action("Index", "Home")" class="btn btn-outline-secondary px-4">
                    Back to Home
                </a>
            </div>
        </div>
    </div>
</div>`
  },

  // 23. Views/Home/About.cshtml
  {
    path: 'Views/Home/About.cshtml',
    name: 'About.cshtml',
    category: 'View',
    language: 'html',
    description: 'About Us page detailing project motivation, objectives, and BCA tech stack.',
    content: `@{
    ViewBag.Title = "About Us";
}

<div class="p-5 mb-4 bg-light rounded-3 shadow-sm border">
    <h1 class="display-6 fw-bold">About BookNest</h1>
    <p class="lead text-muted">
        BookNest is an educational e-commerce web application developed as an ASP.NET .NET Framework MVC Mini Project for BCA (Bachelor of Computer Applications).
    </p>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card h-100 p-4 border-0 shadow-sm">
            <h4 class="fw-bold text-primary"><i class="bi bi-bullseye me-2"></i>Project Objectives</h4>
            <ul class="mt-3 text-secondary">
                <li class="mb-2">Demonstrate the 3-tier Model-View-Controller (MVC) architectural pattern in C#.</li>
                <li class="mb-2">Implement full database persistence using Entity Framework 6 and SQL Server LocalDB.</li>
                <li class="mb-2">Manage user state with in-process Session for the shopping cart.</li>
                <li class="mb-2">Apply Bootstrap 5 for clean, responsive, and mobile-friendly UI layout.</li>
                <li class="mb-2">Provide a complete working project ready for college submission, viva voce, and GitHub hosting.</li>
            </ul>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100 p-4 border-0 shadow-sm">
            <h4 class="fw-bold text-success"><i class="bi bi-cpu me-2"></i>Technology Stack</h4>
            <table class="table table-borderless mt-3">
                <tr>
                    <td class="fw-bold text-muted">Framework:</td>
                    <td>ASP.NET MVC 5 (.NET Framework 4.8)</td>
                </tr>
                <tr>
                    <td class="fw-bold text-muted">Language:</td>
                    <td>C# 10 / 11</td>
                </tr>
                <tr>
                    <td class="fw-bold text-muted">ORM:</td>
                    <td>Entity Framework 6 (Code First / Database First)</td>
                </tr>
                <tr>
                    <td class="fw-bold text-muted">Database:</td>
                    <td>Microsoft SQL Server / LocalDB</td>
                </tr>
                <tr>
                    <td class="fw-bold text-muted">Frontend:</td>
                    <td>Razor Engine, HTML5, CSS3, Bootstrap 5</td>
                </tr>
                <tr>
                    <td class="fw-bold text-muted">Version Control:</td>
                    <td>Git & GitHub</td>
                </tr>
            </table>
        </div>
    </div>
</div>`
  },

  // 24. Content/Site.css
  {
    path: 'Content/Site.css',
    name: 'Site.css',
    category: 'Content',
    language: 'css',
    description: 'Custom CSS stylesheet extending Bootstrap styles for cards, typography, and badges.',
    content: `/* Custom styles for BookNest ASP.NET MVC */
body {
    background-color: #f8f9fa;
    color: #333333;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.book-card-img {
    transition: transform 0.25s ease-in-out;
}

.card:hover .book-card-img {
    transform: scale(1.02);
}

.card {
    transition: box-shadow 0.25s ease, transform 0.2s ease;
    border-radius: 10px;
    overflow: hidden;
}

.card:hover {
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08) !important;
}

.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
}

.btn-warning:hover {
    background-color: #e0a800;
    border-color: #d39e00;
}

.badge {
    font-weight: 500;
    letter-spacing: 0.3px;
}

footer {
    letter-spacing: 0.2px;
}`
  },

  // 25. BookNestDB.sql
  {
    path: 'Database/BookNestDB.sql',
    name: 'BookNestDB.sql',
    category: 'Database',
    language: 'sql',
    description: 'Complete SQL Server script to create database, tables, primary/foreign keys, and insert 10 sample books.',
    content: `-- =========================================================================
-- BookNest Online Book Store - SQL Server Database Setup Script
-- Compatible with SQL Server 2014, 2016, 2019, 2022 & SQL Server LocalDB
-- =========================================================================

-- 1. Create Database if it does not already exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'BookNestDB')
BEGIN
    CREATE DATABASE [BookNestDB];
END
GO

USE [BookNestDB];
GO

-- 2. Drop Existing Tables in Reverse Dependency Order (if re-running script)
IF OBJECT_ID('dbo.OrderDetails', 'U') IS NOT NULL DROP TABLE dbo.OrderDetails;
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.ContactMessages', 'U') IS NOT NULL DROP TABLE dbo.ContactMessages;
IF OBJECT_ID('dbo.Books', 'U') IS NOT NULL DROP TABLE dbo.Books;
GO

-- 3. Create Books Table
CREATE TABLE [dbo].[Books] (
    [BookId] INT IDENTITY(1,1) NOT NULL,
    [BookName] NVARCHAR(150) NOT NULL,
    [Author] NVARCHAR(100) NOT NULL,
    [Category] NVARCHAR(50) NOT NULL,
    [Price] DECIMAL(18, 2) NOT NULL,
    [Description] NVARCHAR(1000) NOT NULL,
    [ImageUrl] NVARCHAR(500) NULL,
    [StockQuantity] INT NOT NULL DEFAULT 10,
    CONSTRAINT [PK_Books] PRIMARY KEY CLUSTERED ([BookId] ASC)
);
GO

-- 4. Create ContactMessages Table
CREATE TABLE [dbo].[ContactMessages] (
    [ContactId] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(100) NOT NULL,
    [Email] NVARCHAR(120) NOT NULL,
    [Phone] NVARCHAR(15) NOT NULL,
    [Message] NVARCHAR(1000) NOT NULL,
    [CreatedDate] DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_ContactMessages] PRIMARY KEY CLUSTERED ([ContactId] ASC)
);
GO

-- 5. Create Orders Table
CREATE TABLE [dbo].[Orders] (
    [OrderId] INT IDENTITY(1,1) NOT NULL,
    [CustomerName] NVARCHAR(100) NOT NULL,
    [Email] NVARCHAR(120) NOT NULL,
    [Phone] NVARCHAR(15) NOT NULL,
    [Address] NVARCHAR(300) NOT NULL,
    [OrderDate] DATETIME NOT NULL DEFAULT GETDATE(),
    [TotalAmount] DECIMAL(18, 2) NOT NULL,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Confirmed',
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderId] ASC)
);
GO

-- 6. Create OrderDetails Table
CREATE TABLE [dbo].[OrderDetails] (
    [OrderDetailId] INT IDENTITY(1,1) NOT NULL,
    [OrderId] INT NOT NULL,
    [BookId] INT NOT NULL,
    [Quantity] INT NOT NULL,
    [Price] DECIMAL(18, 2) NOT NULL,
    CONSTRAINT [PK_OrderDetails] PRIMARY KEY CLUSTERED ([OrderDetailId] ASC),
    CONSTRAINT [FK_OrderDetails_Orders] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Orders] ([OrderId]) ON DELETE CASCADE,
    CONSTRAINT [FK_OrderDetails_Books] FOREIGN KEY ([BookId]) REFERENCES [dbo].[Books] ([BookId])
);
GO

-- 7. Insert 10 Realistic Sample Books
INSERT INTO [dbo].[Books] ([BookName], [Author], [Category], [Price], [Description], [ImageUrl], [StockQuantity])
VALUES
(N'Clean Code: A Handbook of Agile Software Craftsmanship', N'Robert C. Martin', N'Programming', 599.00, N'Even bad code can function. But if code isn''t clean, it can bring a development organization to its knees. Master naming, functions, and formatting.', N'https://images.unsplash.com/photo-1532012164546-f432f2e3777a?w=400', 15),
(N'The Pragmatic Programmer: Your Journey to Mastery', N'Andrew Hunt & David Thomas', N'Programming', 699.00, N'Illustrates best approaches and major pitfalls in software development, architecture, testing, and team discipline.', N'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400', 12),
(N'Java: The Complete Reference (12th Edition)', N'Herbert Schildt', N'Programming', 799.00, N'The definitive guide to Java SE programming. Explains how to develop, compile, debug, and run Java programs.', N'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400', 20),
(N'Atomic Habits: Proven Way to Build Good Habits', N'James Clear', N'Self Help', 499.00, N'A practical guide to breaking bad habits and creating good ones using small 1% daily increments.', N'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400', 25),
(N'HTML and CSS: Design and Build Websites', N'Jon Duckett', N'Web Development', 649.00, N'Visual full-color handbook introducing web design, page layout, typography, and styling for beginners.', N'https://images.unsplash.com/photo-1507842229451-7f01be7ff612?w=400', 18),
(N'JavaScript: The Definitive Guide', N'David Flanagan', N'Web Development', 749.00, N'Comprehensive guide to modern ECMAScript standards, asynchronous promises, DOM manipulation, and frontend APIs.', N'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400', 14),
(N'Database System Concepts (7th Edition)', N'Abraham Silberschatz & Henry Korth', N'Computer Science', 899.00, N'Standard textbook covering relational models, SQL queries, normalization, transactions, and indexing.', N'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400', 10),
(N'Introduction to Algorithms (CLRS)', N'Thomas H. Cormen', N'Computer Science', 999.00, N'Rigorous and comprehensive textbook on data structures, sorting algorithms, dynamic programming, and graphs.', N'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=400', 8),
(N'The Psychology of Money', N'Morgan Housel', N'Self Help', 399.00, N'Timeless lessons on wealth, greed, and happiness. Teaches how behavior matters more than analytical intellect.', N'https://images.unsplash.com/photo-1592496431122-2349e0fbc666?w=400', 30),
(N'C# 10 and .NET 6 – Modern Cross-Platform Dev', N'Mark J. Price', N'Programming', 849.00, N'Build websites, web services, and database-driven applications with C#, ASP.NET, and Entity Framework.', N'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=400', 16);
GO

-- 8. Verify Table Record Counts
SELECT 'Books' AS [TableName], COUNT(*) AS [RecordCount] FROM [dbo].[Books]
UNION ALL
SELECT 'ContactMessages', COUNT(*) FROM [dbo].[ContactMessages]
UNION ALL
SELECT 'Orders', COUNT(*) FROM [dbo].[Orders]
UNION ALL
SELECT 'OrderDetails', COUNT(*) FROM [dbo].[OrderDetails];
GO`
  },

  // 26. .gitignore
  {
    path: '.gitignore',
    name: '.gitignore',
    category: 'Documentation',
    language: 'text',
    description: 'Standard Visual Studio .gitignore file to exclude bin, obj, .vs, and user-specific files.',
    content: `## Visual Studio temp and binary files
[Bb]in/
[Oo]bj/
.vs/
*.user
*.suo
*.userosscache
*.sln.docstates
*.DotSettings.user

## Build Results
[Dd]ebug/
[Rr]elease/
x64/
x86/
build/
bld/

## Packages
packages/
*.nupkg

## SQL Server data files
*.mdf
*.ldf`
  },

  // 27. README.md
  {
    path: 'README.md',
    name: 'README.md',
    category: 'Documentation',
    language: 'markdown',
    description: 'Comprehensive GitHub documentation for college submission and evaluation.',
    content: `# BookNest – Online Book Store

> An ASP.NET MVC (.NET Framework) Web Application developed as a BCA Mini Project.

---

## 📌 Project Overview
**BookNest** is a 3-tier database-driven e-commerce web application where college students and book lovers can browse, search, inspect, and order textbooks and literature online. The system incorporates complete CRUD operations, Entity Framework database connectivity, and an in-memory session cart.

## 🚀 Key Features
- **Responsive 6-Page Navigation**: Home, Books Catalog, Book Details, Shopping Cart, Checkout, About Us, and Contact Us.
- **Dynamic Catalog**: Filter books by category (*Programming*, *Web Development*, *Computer Science*, *Self Help*) or search by title and author.
- **Session-Based Cart**: Add books, modify quantity, calculate dynamic subtotals, and remove items.
- **Checkout & Order Storage**: Simulated checkout saving master-detail records in SQL Server (\`Orders\` and \`OrderDetails\` tables).
- **Contact Form Validation**: Full client & server-side data validation saving messages to \`ContactMessages\` table.
- **Modern Bootstrap 5 UI**: Clean cards, hover states, badges, and mobile-friendly layout.

---

## 🛠️ Technologies Used
- **Backend**: C#, ASP.NET MVC 5 (.NET Framework 4.8)
- **Database**: Microsoft SQL Server / LocalDB (\`BookNestDB\`)
- **ORM**: Entity Framework 6 (Code First / Database First)
- **Frontend**: Razor View Engine, HTML5, CSS3, Bootstrap 5, JavaScript
- **IDE**: Visual Studio 2019 / 2022
- **Version Control**: Git & GitHub

---

## 📂 Project Structure
\`\`\`
BookNest
│
├── Controllers
│   ├── HomeController.cs        # Home & About pages
│   ├── BooksController.cs       # Catalog search & Book Details
│   ├── CartController.cs        # Session-backed cart logic
│   ├── ContactController.cs     # Inquiry form handler
│   └── OrderController.cs       # Checkout & simulated order placement
│
├── Models
│   ├── Book.cs                  # Book entity with data annotations
│   ├── ContactMessage.cs        # Contact form entity
│   ├── Order.cs                 # Order master entity
│   ├── OrderDetail.cs           # Order detail line items
│   ├── CartItem.cs              # Session cart view model
│   └── BookNestDbContext.cs     # Entity Framework DbContext
│
├── Views
│   ├── Shared/_Layout.cshtml    # Master layout with navbar & footer
│   ├── Home/Index.cshtml        # Landing page & featured books
│   ├── Home/About.cshtml        # Project objectives & tech stack
│   ├── Books/Index.cshtml       # Filterable catalog with search
│   ├── Books/Details.cshtml     # Detailed book view
│   ├── Cart/Index.cshtml        # Shopping cart table
│   ├── Contact/Index.cshtml     # Validated contact form
│   ├── Order/Checkout.cshtml    # Customer address & order review
│   └── Order/OrderSuccess.cshtml# Order confirmation screen
│
├── Content/Site.css             # Custom styling
├── Database/BookNestDB.sql      # SQL Server creation & sample data script
├── Web.config                   # Configuration & Connection Strings
├── Global.asax.cs               # App startup & route registration
└── BookNest.sln                 # Visual Studio solution file
\`\`\`

---

## ⚙️ Installation & How to Run in Visual Studio
1. **Clone or Download the Repository**:
   \`\`\`bash
   git clone https://github.com/your-username/BookNest-ASP.NET-MVC.git
   \`\`\`
2. **Execute Database Script**:
   - Open **SQL Server Management Studio (SSMS)** or Visual Studio **SQL Server Object Explorer**.
   - Open \`Database/BookNestDB.sql\` and click **Execute**.
   - This creates \`BookNestDB\` and populates 10 sample books.
3. **Open the Solution**:
   - Double-click \`BookNest.sln\` to open in Visual Studio.
4. **Restore NuGet Packages**:
   - Right-click Solution in Solution Explorer -> **Restore NuGet Packages**.
5. **Verify Connection String**:
   - Open \`Web.config\` and verify \`Data Source=(LocalDb)\\MSSQLLocalDB\` matches your local SQL Server instance.
6. **Run the Project**:
   - Press **F5** or click the green **IIS Express (Google Chrome)** button.

---

## 🎓 BCA Viva Questions Covered
- Architecture of ASP.NET MVC and separation of concerns
- Difference between ASP.NET Web Forms and ASP.NET MVC
- Session state management for shopping carts
- Role of Entity Framework DbContext and LINQ queries
- Razor syntax \`@Html\` helpers and Data Annotations for validation

---

## 👨‍💻 Author
- **Student Name**: BCA Final Year Student
- **Course**: Bachelor of Computer Applications (BCA)
- **Institution**: Department of Computer Applications
`
  },

  // 28. Default Document Redirect
  {
    path: 'index.html',
    name: 'index.html',
    category: 'Content',
    language: 'html',
    description: 'Default entry document that redirects directly to /Home/Index to prevent HTTP 403.14 Forbidden error in IIS Express.',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="refresh" content="0;url=/Home/Index" />
    <title>Redirecting to BookNest...</title>
</head>
<body style="font-family: Arial, sans-serif; text-align: center; padding-top: 50px;">
    <h2>Loading BookNest Online Store...</h2>
    <p>If you are not redirected automatically within 2 seconds, <a href="/Home/Index" style="font-size: 18px; color: #0d6efd; font-weight: bold;">click here to enter the store</a>.</p>
</body>
</html>`
  }
];
