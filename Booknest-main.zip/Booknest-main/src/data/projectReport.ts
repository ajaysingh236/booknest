export interface ReportSection {
  number: number;
  title: string;
  content: string;
}

export const PROJECT_REPORT_SECTIONS: ReportSection[] = [
  {
    number: 1,
    title: 'Project Title',
    content: 'BookNest – Online Book Store (An ASP.NET MVC .NET Framework Mini Project for BCA)'
  },
  {
    number: 2,
    title: 'Abstract',
    content: 'The "BookNest – Online Book Store" is an e-commerce web platform developed using ASP.NET MVC architecture on the .NET Framework 4.8 platform with Microsoft SQL Server LocalDB as the backend relational database. The system enables academic institutions, college students, and book enthusiasts to digitally browse, search, inspect, and order textbooks and technical literature. It provides a responsive, user-friendly interface built with Bootstrap 5, implements complete separation of concerns via the Model-View-Controller design pattern, utilizes Entity Framework 6 for seamless database operations, and leverages ASP.NET Session state for managing shopping cart interactions. The project demonstrates core principles of modern web engineering, relational database normalization, and secure form validation.'
  },
  {
    number: 3,
    title: 'Introduction',
    content: 'In the modern digital era, online commerce and digital catalogs have transformed access to educational and academic materials. Physical book browsing often entails traveling to physical stores, facing inventory shortages, and dealing with inefficient manual billing. BookNest addresses these challenges by offering a centralized web storefront where academic, programming, self-development, and computer science books are categorized, searchable, and available for simulated online ordering with real-time stock indicators.'
  },
  {
    number: 4,
    title: 'Problem Statement',
    content: 'Traditional brick-and-mortar bookstores and manual inventory registers suffer from several limitations:\n1. Lack of accessible digital catalogs for students to check stock availability before visiting.\n2. Manual billing and paper receipt processing causing long wait times.\n3. Inability for customers to easily search across authors, genres, and pricing tiers.\n4. Difficulty in logging inquiries and customer feedback systematically.'
  },
  {
    number: 5,
    title: 'Objectives',
    content: 'The primary objectives of the BookNest project are:\n• To design and deploy a responsive 3-tier ASP.NET MVC web application on the .NET Framework.\n• To establish automated database persistence using Entity Framework 6 and Microsoft SQL Server.\n• To implement an in-memory shopping cart utilizing ASP.NET Session state management.\n• To provide dynamic book search and categorization across computer science, programming, and academic titles.\n• To build a validated contact feedback module storing inquiries directly in SQL tables.\n• To generate a simulated checkout and order creation workflow with unique order numbers.'
  },
  {
    number: 6,
    title: 'Scope of the Project',
    content: 'The scope of this mini project encompasses:\n• Customer-facing catalog with search, category filtering, and book details.\n• Cart management with quantity adjustments, line-item subtotaling, and item removal.\n• Checkout processing creating master-detail relational records in `Orders` and `OrderDetails` tables.\n• Inquiry management via a validated contact form.\n• Academic submission suitability for BCA semester evaluation and practical viva.'
  },
  {
    number: 7,
    title: 'Existing System',
    content: 'The existing manual system relies on physical visits to campus bookstores, printed paper catalogs, manual physical ledgers for recording transactions, and telephone-based book inquiries. This results in slow processing, prone-to-error handwritten logs, and zero visibility into real-time stock levels for remote students.'
  },
  {
    number: 8,
    title: 'Proposed System',
    content: 'The proposed BookNest web portal automates all manual processes by introducing:\n• Instant digital catalog access 24/7 from any web browser.\n• Instant search across titles and authors using LINQ database queries.\n• Transparent pricing, detailed book summaries, and real-time stock count badges.\n• Automated subtotal, discount, and grand total calculations via session cart.\n• Structured relational database storage preventing duplicate or lost records.'
  },
  {
    number: 9,
    title: 'Advantages of the Proposed System',
    content: '• High Availability: Available round-the-clock for college students.\n• Data Accuracy: Automated calculations eliminate manual calculation errors.\n• Responsive Design: Fully usable across desktop computers, tablets, and smartphones.\n• Architectural Cleanliness: MVC separation ensures testability and clean code maintenance.\n• Scalability: Entity Framework ORM allows straightforward scaling to enterprise SQL Server clusters.'
  },
  {
    number: 10,
    title: 'Hardware Requirements',
    content: '• Processor: Intel Core i3 / AMD Ryzen 3 or higher (Intel Core i5 recommended)\n• RAM: Minimum 4 GB RAM (8 GB or higher recommended for Visual Studio and LocalDB)\n• Storage: 2 GB free hard disk space for Visual Studio, IIS Express, and SQL LocalDB\n• Display: 1366 x 768 resolution minimum (1920 x 1080 recommended)\n• Input Devices: Keyboard and Mouse'
  },
  {
    number: 11,
    title: 'Software Requirements',
    content: '• Operating System: Windows 10 / Windows 11 (64-bit)\n• Development Environment: Microsoft Visual Studio 2019 or Visual Studio 2022 (Community Edition)\n• Framework: Microsoft .NET Framework 4.8\n• Technology: ASP.NET MVC 5\n• Database Engine: Microsoft SQL Server 2019 / 2022 Express or SQL Server LocalDB (v13.0+)\n• Database Management Tool: SQL Server Management Studio (SSMS) or VS Server Explorer\n• Web Browser: Google Chrome, Microsoft Edge, or Mozilla Firefox\n• Version Control: Git 2.x and GitHub account'
  },
  {
    number: 12,
    title: 'Functional Requirements',
    content: '1. User Navigation: Seamless navigation across Home, Catalog, Details, Cart, Checkout, About, and Contact pages.\n2. Book Filtering: Capability to filter books by categories and search keywords.\n3. Book Inspection: Viewing full book overview, author, price, and stock quantity.\n4. Shopping Cart: Adding items, incrementing/decrementing quantities, and clearing cart.\n5. Checkout Simulation: Entering customer name, mobile, delivery address, and confirming simulated order.\n6. Contact Form: Inputting customer inquiries with validation on 10-digit phone and email format.'
  },
  {
    number: 13,
    title: 'Non-Functional Requirements',
    content: '• Usability: Intuitive UI requiring no special training for students.\n• Performance: Fast page load times under 1 second on local IIS Express.\n• Security: Anti-forgery tokens (`[ValidateAntiForgeryToken]`) protecting against CSRF attacks, parameterized LINQ queries preventing SQL injection.\n• Reliability: Graceful handling of missing items and database connection failures.\n• Maintainability: Modular C# code organized in standard MVC directories.'
  },
  {
    number: 14,
    title: 'Project Modules',
    content: '1. Home Module: Hero banner, promotional callouts, and featured books showcase.\n2. Catalog & Search Module: Grid of book cards, dynamic search box, category pill filter buttons.\n3. Book Details Module: Comprehensive book profile with high-res cover, description, and quantity selector.\n4. Shopping Cart Module: Session-backed cart list with item deletion and subtotal calculation.\n5. Order & Checkout Module: Master-detail transactional order creation with delivery confirmation.\n6. Feedback & Contact Module: Form with Data Annotations saving messages to SQL Server.'
  },
  {
    number: 15,
    title: 'Technology Stack Details',
    content: '• C# (C-Sharp): Strongly-typed, object-oriented language developed by Microsoft.\n• ASP.NET MVC 5: Server-side web application framework with clean separation of concerns.\n• Entity Framework 6 (EF6): Object-relational mapper for database queries using LINQ.\n• Razor View Engine: Templating syntax combining HTML5 with C# server code.\n• Bootstrap 5: Responsive mobile-first CSS framework with flexbox grid and utility classes.\n• SQL Server LocalDB: In-process database engine requiring zero background service overhead.'
  },
  {
    number: 16,
    title: 'Database Design & Schema',
    content: 'The database `BookNestDB` consists of 4 normalized relational tables:\n\n1. `Books` Table:\n   • BookId (INT, PK, Identity)\n   • BookName (NVARCHAR(150), Not Null)\n   • Author (NVARCHAR(100), Not Null)\n   • Category (NVARCHAR(50), Not Null)\n   • Price (DECIMAL(18,2), Not Null)\n   • Description (NVARCHAR(1000), Not Null)\n   • ImageUrl (NVARCHAR(500), Null)\n   • StockQuantity (INT, Not Null)\n\n2. `ContactMessages` Table:\n   • ContactId (INT, PK, Identity)\n   • Name (NVARCHAR(100), Not Null)\n   • Email (NVARCHAR(120), Not Null)\n   • Phone (NVARCHAR(15), Not Null)\n   • Message (NVARCHAR(1000), Not Null)\n   • CreatedDate (DATETIME, Default GETDATE())\n\n3. `Orders` Table:\n   • OrderId (INT, PK, Identity)\n   • CustomerName (NVARCHAR(100), Not Null)\n   • Email (NVARCHAR(120), Not Null)\n   • Phone (NVARCHAR(15), Not Null)\n   • Address (NVARCHAR(300), Not Null)\n   • OrderDate (DATETIME, Default GETDATE())\n   • TotalAmount (DECIMAL(18,2), Not Null)\n   • Status (NVARCHAR(50), Default \'Confirmed\')\n\n4. `OrderDetails` Table:\n   • OrderDetailId (INT, PK, Identity)\n   • OrderId (INT, FK -> Orders.OrderId, ON DELETE CASCADE)\n   • BookId (INT, FK -> Books.BookId)\n   • Quantity (INT, Not Null)\n   • Price (DECIMAL(18,2), Not Null)'
  },
  {
    number: 17,
    title: 'System Flowchart & Architecture',
    content: '1. User Request: Browser sends HTTP GET/POST request (e.g. `/Books/Index`).\n2. Routing Engine: `RouteConfig.cs` maps the URL to `BooksController.Index()`.\n3. Controller Processing: Controller calls `BookNestDbContext` to query `_db.Books`.\n4. Database Query: Entity Framework translates LINQ expression into T-SQL `SELECT * FROM Books`.\n5. Model Binding: Data returned from SQL Server is mapped into `List<Book>` objects.\n6. View Rendering: Controller passes model to `Index.cshtml`. Razor engine generates HTML markup.\n7. Response: Rendered HTML is returned to the user\'s web browser with HTTP 200 OK.'
  },
  {
    number: 18,
    title: 'Testing and Verification',
    content: 'The system has undergone black-box functional testing:\n• Test Case 1: Route navigation across all 6 pages confirmed with 100% link integrity.\n• Test Case 2: Catalog category filtering accurately filters records without page errors.\n• Test Case 3: Keyword search retrieves matching title and author substrings.\n• Test Case 4: Cart state persists between multiple page transitions using Session.\n• Test Case 5: Contact form blocks invalid email/phone numbers using Data Annotation validation.\n• Test Case 6: Checkout successfully commits parent `Orders` and child `OrderDetails` records.'
  },
  {
    number: 19,
    title: 'Future Scope',
    content: '• Integration with payment gateways (Razorpay, Paytm, Stripe) for real digital payments.\n• User authentication, registration, and role-based access control (RBAC) via ASP.NET Identity.\n• Comprehensive Admin Dashboard with book inventory management and sales charts.\n• Customer product reviews, ratings, and recommendations engine.\n• Automated email and SMS order dispatch confirmations via SendGrid / Twilio.'
  },
  {
    number: 20,
    title: 'Conclusion',
    content: 'The "BookNest – Online Book Store" mini project successfully demonstrates the design and practical implementation of an e-commerce web application using ASP.NET .NET Framework MVC and Microsoft SQL Server. The application fulfills all academic objectives of the BCA curriculum by demonstrating 3-tier architecture, clean separation of concerns, object-relational mapping with Entity Framework, session state management, and modern responsive design using Bootstrap 5. The project is fully functional, well-documented, and ready for viva voce examination and GitHub deployment.'
  }
];
