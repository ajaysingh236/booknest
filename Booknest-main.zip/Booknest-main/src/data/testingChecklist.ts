import { TestCase } from '../types';

export const TESTING_CHECKLIST: TestCase[] = [
  {
    id: 1,
    testCase: 'Home page opens',
    module: 'Home Module',
    expectedResult: 'Home page displayed with hero banner, welcome message, and 4 featured books.',
    status: 'Pass',
    remarks: 'Controller Home/Index returns View with featured books model.'
  },
  {
    id: 2,
    testCase: 'Navigation between pages',
    module: 'Layout / Navigation',
    expectedResult: 'All navigation bar links (Home, Books, About, Contact, Cart) work without broken links (404).',
    status: 'Pass',
    remarks: 'Razor @Url.Action routes correctly configured in _Layout.cshtml.'
  },
  {
    id: 3,
    testCase: 'Books catalog displays',
    module: 'Books Module',
    expectedResult: 'Books displayed in attractive Bootstrap cards with title, author, price, category badge, and stock count.',
    status: 'Pass',
    remarks: 'LINQ query fetches all active books from SQL Server LocalDB.'
  },
  {
    id: 4,
    testCase: 'Book details page',
    module: 'Books Module',
    expectedResult: 'Correct book details, full description, price in ₹, and stock availability displayed on clicking View Details.',
    status: 'Pass',
    remarks: 'Books/Details/{id} finds book by primary key and renders Details view.'
  },
  {
    id: 5,
    testCase: 'Add to Cart functionality',
    module: 'Cart Module',
    expectedResult: 'Selected book added to session cart, quantity increments if already present, navbar badge updates.',
    status: 'Pass',
    remarks: 'CartController.AddToCart creates or updates List<CartItem> in Session["Cart"].'
  },
  {
    id: 6,
    testCase: 'Remove Cart Item',
    module: 'Cart Module',
    expectedResult: 'Item successfully removed from cart list and grand total updates immediately.',
    status: 'Pass',
    remarks: 'CartController.RemoveFromCart filters out item by BookId.'
  },
  {
    id: 7,
    testCase: 'Quantity Update & Subtotal',
    module: 'Cart Module',
    expectedResult: 'Quantity changes recalculate line-item subtotal and overall grand total accurately.',
    status: 'Pass',
    remarks: 'CartItem.Subtotal calculated dynamically (Price * Quantity).'
  },
  {
    id: 8,
    testCase: 'Contact Form Validation & Submission',
    module: 'Contact Module',
    expectedResult: 'Validation prevents empty fields / invalid phone or email; valid form saves to ContactMessages table with success alert.',
    status: 'Pass',
    remarks: 'ModelState.IsValid check passed and _db.ContactMessages.Add() executed.'
  },
  {
    id: 9,
    testCase: 'Order & Simulated Checkout',
    module: 'Order Module',
    expectedResult: 'Checkout saves customer details to Orders table and line items to OrderDetails table, then redirects to OrderSuccess with unique order ID.',
    status: 'Pass',
    remarks: 'Transactional commit via Entity Framework; Session["Cart"] cleared after checkout.'
  },
  {
    id: 10,
    testCase: 'Database Persistence (SQL Server)',
    module: 'Database / EF',
    expectedResult: 'All records (Books, ContactMessages, Orders, OrderDetails) stored correctly and verified in database explorer.',
    status: 'Pass',
    remarks: 'Primary keys, foreign keys, and timestamps verified in SQL schema.'
  }
];
