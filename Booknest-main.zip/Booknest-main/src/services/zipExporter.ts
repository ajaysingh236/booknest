import JSZip from 'jszip';
import { DOTNET_PROJECT_FILES } from '../data/dotNetProjectFiles';

export async function generateAndDownloadProjectZip(): Promise<void> {
  try {
    const staticRes = await fetch('/BookNest-ASP.NET-MVC-Project.zip');
    if (staticRes.ok) {
      const blob = await staticRes.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'BookNest-ASP.NET-MVC-Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
      return;
    }
  } catch {
    // If fetch failed, proceed with client-side JSZip assembly
  }

  const zip = new JSZip();
  const rootFolder = zip.folder('BookNest-ASP.NET-MVC');

  if (!rootFolder) {
    throw new Error('Failed to create root folder in ZIP');
  }

  for (const file of DOTNET_PROJECT_FILES) {
    if (file.path === 'BookNest.sln') {
      rootFolder.file('BookNest.sln', file.content);
    } else {
      rootFolder.file(`BookNest/${file.path}`, file.content);
    }
  }

  const csprojContent = `<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="15.0" DefaultTargets="Build" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <Import Project="$(MSBuildExtensionsPath)\\$(MSBuildToolsVersion)\\Microsoft.Common.props" Condition="Exists('$(MSBuildExtensionsPath)\\$(MSBuildToolsVersion)\\Microsoft.Common.props')" />
  <PropertyGroup>
    <Configuration Condition=" '$(Configuration)' == '' ">Debug</Configuration>
    <Platform Condition=" '$(Platform)' == '' ">AnyCPU</Platform>
    <ProductVersion></ProductVersion>
    <SchemaVersion>2.0</SchemaVersion>
    <ProjectGuid>{A87B2E40-1A22-4D93-9F94-52E2A68181A0}</ProjectGuid>
    <ProjectTypeGuids>{349c5851-65df-11da-9384-00065b846f21};{fae04ec0-301f-11d3-bf4b-00c04f79efbc}</ProjectTypeGuids>
    <OutputType>Library</OutputType>
    <AppDesignerFolder>Properties</AppDesignerFolder>
    <RootNamespace>BookNest</RootNamespace>
    <AssemblyName>BookNest</AssemblyName>
    <TargetFrameworkVersion>v4.8</TargetFrameworkVersion>
    <MvcBuildViews>false</MvcBuildViews>
    <UseIISExpress>true</UseIISExpress>
    <Use64BitIISExpress />
    <IISExpressSSLPort />
    <IISExpressAnonymousAuthentication />
    <IISExpressWindowsAuthentication />
    <IISExpressUseClassicPipelineMode />
    <UseGlobalApplicationHostFile />
  </PropertyGroup>
  <ItemGroup>
    <Reference Include="System" />
    <Reference Include="System.Data" />
    <Reference Include="System.Drawing" />
    <Reference Include="System.Web.DynamicData" />
    <Reference Include="System.Web.Entity" />
    <Reference Include="System.Web.ApplicationServices" />
    <Reference Include="System.ComponentModel.DataAnnotations" />
    <Reference Include="System.Core" />
    <Reference Include="System.Web" />
    <Reference Include="System.Web.Extensions" />
    <Reference Include="System.Web.Abstractions" />
    <Reference Include="System.Web.Routing" />
    <Reference Include="System.Xml" />
    <Reference Include="System.Configuration" />
    <Reference Include="System.Web.Services" />
    <Reference Include="System.EnterpriseServices" />
    <Reference Include="Microsoft.Web.Infrastructure, Version=1.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL" />
    <Reference Include="System.Web.Helpers, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL" />
    <Reference Include="System.Web.Mvc, Version=5.2.9.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL" />
    <Reference Include="System.Web.Razor, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL" />
    <Reference Include="System.Web.WebPages, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL" />
    <Reference Include="EntityFramework, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, processorArchitecture=MSIL" />
    <Reference Include="EntityFramework.SqlServer, Version=6.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089, processorArchitecture=MSIL" />
  </ItemGroup>
  <ItemGroup>
    <Compile Include="App_Start\\RouteConfig.cs" />
    <Compile Include="Controllers\\BooksController.cs" />
    <Compile Include="Controllers\\CartController.cs" />
    <Compile Include="Controllers\\ContactController.cs" />
    <Compile Include="Controllers\\HomeController.cs" />
    <Compile Include="Controllers\\OrderController.cs" />
    <Compile Include="Global.asax.cs">
      <DependentUpon>Global.asax</DependentUpon>
    </Compile>
    <Compile Include="Models\\Book.cs" />
    <Compile Include="Models\\BookNestDbContext.cs" />
    <Compile Include="Models\\CartItem.cs" />
    <Compile Include="Models\\ContactMessage.cs" />
    <Compile Include="Models\\Order.cs" />
    <Compile Include="Models\\OrderDetail.cs" />
  </ItemGroup>
  <ItemGroup>
    <Content Include="Global.asax" />
    <Content Include="index.html" />
    <Content Include="Content\\Site.css" />
    <Content Include="Database\\BookNestDB.sql" />
    <Content Include="Web.config" />
    <Content Include="Views\\Web.config" />
    <Content Include="Views\\_ViewStart.cshtml" />
    <Content Include="Views\\Shared\\_Layout.cshtml" />
    <Content Include="Views\\Home\\Index.cshtml" />
    <Content Include="Views\\Home\\About.cshtml" />
    <Content Include="Views\\Books\\Index.cshtml" />
    <Content Include="Views\\Books\\Details.cshtml" />
    <Content Include="Views\\Cart\\Index.cshtml" />
    <Content Include="Views\\Contact\\Index.cshtml" />
    <Content Include="Views\\Order\\Checkout.cshtml" />
    <Content Include="Views\\Order\\Success.cshtml" />
  </ItemGroup>
  <ItemGroup>
    <None Include="packages.config" />
  </ItemGroup>
  <Import Project="$(MSBuildBinPath)\\Microsoft.CSharp.targets" />
</Project>`;

  rootFolder.file('BookNest/BookNest.csproj', csprojContent);

  const blob = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = downloadUrl;
  link.download = 'BookNest-ASP.NET-MVC-Project.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(downloadUrl);
}
